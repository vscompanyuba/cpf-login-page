"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { User, Phone, Mail, MapPin, Calendar, ArrowLeft } from "lucide-react"
import Link from "next/link"

interface UserData {
  nome: string
  cpf: string
  email: string
  telefone: string
  endereco: string
  dataNascimento: string
}

export default function DashboardPage() {
  const [userData, setUserData] = useState<UserData | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Simular chamada da API
    const fetchUserData = async () => {
      try {
        // Aqui você faria a chamada real para sua API
        // const response = await fetch('/api/user-data')
        // const data = await response.json()

        // Dados simulados para demonstração
        setTimeout(() => {
          setUserData({
            nome: "João Silva Santos",
            cpf: "123.456.789-00",
            email: "joao.silva@email.com",
            telefone: "(11) 99999-9999",
            endereco: "Rua das Flores, 123 - São Paulo, SP",
            dataNascimento: "15/03/1985",
          })
          setLoading(false)
        }, 1500)
      } catch (error) {
        console.error("Erro ao buscar dados:", error)
        setLoading(false)
      }
    }

    fetchUserData()
  }, [])

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#1857b5] mx-auto mb-4"></div>
          <p className="text-gray-600">Carregando dados do usuário...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <Link href="/" className="flex items-center text-[#1857b5] hover:text-[#0f4389] mr-6">
                <ArrowLeft className="w-5 h-5 mr-2" />
                Voltar
              </Link>
              <img src="/images/gov-br-logo.webp" alt="gov.br" className="h-8 w-auto" />
            </div>
            <Button variant="outline" className="bg-white text-gray-700">
              Sair
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto py-8 px-4">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-800 mb-2">Bem-vindo ao gov.br</h1>
          <p className="text-gray-600">Aqui estão suas informações cadastrais</p>
        </div>

        {userData && (
          <div className="grid gap-6 md:grid-cols-2">
            {/* Dados Pessoais */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <User className="w-5 h-5 mr-2 text-[#1857b5]" />
                  Dados Pessoais
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-gray-500">Nome Completo</label>
                  <p className="text-gray-800 font-medium">{userData.nome}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">CPF</label>
                  <p className="text-gray-800 font-medium">{userData.cpf}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Data de Nascimento</label>
                  <p className="text-gray-800 font-medium flex items-center">
                    <Calendar className="w-4 h-4 mr-2" />
                    {userData.dataNascimento}
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Contato */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Phone className="w-5 h-5 mr-2 text-green-600" />
                  Informações de Contato
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-gray-500">E-mail</label>
                  <p className="text-gray-800 font-medium flex items-center">
                    <Mail className="w-4 h-4 mr-2" />
                    {userData.email}
                  </p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Telefone</label>
                  <p className="text-gray-800 font-medium flex items-center">
                    <Phone className="w-4 h-4 mr-2" />
                    {userData.telefone}
                  </p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Endereço</label>
                  <p className="text-gray-800 font-medium flex items-center">
                    <MapPin className="w-4 h-4 mr-2" />
                    {userData.endereco}
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Ações */}
        <div className="mt-8 flex gap-4">
          <Button className="bg-[#1857b5] hover:bg-[#0f4389] text-white">Atualizar Dados</Button>
          <Button variant="outline" className="bg-white text-gray-700">
            Baixar Comprovante
          </Button>
        </div>
      </main>
    </div>
  )
}
