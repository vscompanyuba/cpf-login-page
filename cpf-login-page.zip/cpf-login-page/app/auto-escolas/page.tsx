"use client"

import { useEffect, useState, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { User, Menu, Mic, Search } from "lucide-react"
import { useSearchParams, useRouter } from "next/navigation"
import Link from "next/link"

interface UserData {
  nome?: string
  cpf?: string
  error?: string
}

export default function AutoEscolasPage() {
  const [userData, setUserData] = useState<UserData | null>(null)
  const [loading, setLoading] = useState(true)
  const [addressData, setAddressData] = useState({
    logradouro: "",
    numero: "",
    bairro: "",
    cidade: "",
    estado: "",
    cep: "",
  })

  const searchParams = useSearchParams()
  const router = useRouter()

  const fetchUserData = useCallback(async (cpf: string) => {
    try {
      setLoading(true)

      const response = await fetch(`/api/cpf?cpf=${cpf}`, {
        method: "GET",
        headers: {
          Accept: "application/json",
        },
      })

      if (response.ok) {
        const data = await response.json()

        let nomeCompleto = null

        if (data?.nome) {
          nomeCompleto = data.nome
        } else if (data?.name) {
          nomeCompleto = data.name
        }

        if (nomeCompleto) {
          const primeiroNome = nomeCompleto.split(" ")[0]

          setUserData({
            nome: primeiroNome,
            cpf: cpf,
          })
        } else {
          throw new Error("Nome não encontrado na resposta da API")
        }
      } else {
        throw new Error("Erro na API")
      }
    } catch (error) {
      console.log("❌ Erro capturado:", error)

      // Fallback com dados simulados
      const nomesPorCPF = {
        "46960142822": "Roberto",
        "12345678900": "João",
        "98765432100": "Maria",
        "11111111111": "Pedro",
        "22222222222": "Ana",
        "33333333333": "Carlos",
        "44444444444": "Lucia",
        "55555555555": "José",
        "66666666666": "Fernanda",
        "77777777777": "Paulo",
        "88888888888": "Beatriz",
      }

      let nomeSimulado = nomesPorCPF[cpf as keyof typeof nomesPorCPF]

      if (!nomeSimulado) {
        const nomes = ["João", "Maria", "Pedro", "Ana", "Carlos", "Lucia", "José", "Fernanda", "Davi", "Beatriz"]
        const indice = Number.parseInt(cpf.slice(-1)) % nomes.length
        nomeSimulado = nomes[indice]
      }

      setUserData({
        nome: nomeSimulado,
        cpf: cpf,
      })
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    // Recuperar dados do endereço do localStorage
    const savedAddress = localStorage.getItem("addressData")
    if (savedAddress) {
      const parsedAddress = JSON.parse(savedAddress)
      setAddressData(parsedAddress)
    }
  }, [])

  useEffect(() => {
    const cpfFromUrl = searchParams.get("cpf")

    if (cpfFromUrl && !userData) {
      fetchUserData(cpfFromUrl)
    } else if (!cpfFromUrl) {
      setLoading(false)
    }
  }, [searchParams, fetchUserData, userData])

  const handleProsseguir = () => {
    const cpfFromUrl = searchParams.get("cpf")
    router.push(`/agendamento?cpf=${cpfFromUrl}`)
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-white">
        <header className="bg-white shadow-sm">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-14">
              <div className="flex items-center space-x-4">
                <img src="/images/gov-br-logo.webp" alt="gov.br" className="h-6 w-auto" />
                <Button variant="ghost" size="sm" className="p-2">
                  <div className="flex flex-col space-y-1">
                    <div className="w-5 h-0.5 bg-gray-700 rounded-sm"></div>
                    <div className="w-5 h-0.5 bg-gray-700 rounded-sm"></div>
                    <div className="w-5 h-0.5 bg-gray-700 rounded-sm"></div>
                  </div>
                </Button>
                <Button variant="ghost" size="sm" className="p-2">
                  <div className="flex flex-col space-y-1 items-center">
                    <div className="w-1 h-1 bg-gray-700 rounded-full"></div>
                    <div className="w-1 h-1 bg-gray-700 rounded-full"></div>
                    <div className="w-1 h-1 bg-gray-700 rounded-full"></div>
                  </div>
                </Button>
                <Button variant="ghost" size="sm" className="p-2">
                  <div className="w-5 h-5 border-2 border-gray-700 rounded-full flex items-center justify-center">
                    <div className="w-2 h-1 border-l-2 border-b-2 border-gray-700 rotate-[-45deg] translate-y-[-1px]"></div>
                  </div>
                </Button>
                <Button variant="ghost" size="sm" className="p-2">
                  <div className="grid grid-cols-2 gap-1">
                    <div className="w-1.5 h-1.5 bg-gray-700 rounded-sm"></div>
                    <div className="w-1.5 h-1.5 bg-gray-700 rounded-sm"></div>
                    <div className="w-1.5 h-1.5 bg-gray-700 rounded-sm"></div>
                    <div className="w-1.5 h-1.5 bg-gray-700 rounded-sm"></div>
                  </div>
                </Button>
              </div>
              <div className="bg-[#1857b5] text-white px-4 py-2 rounded-full flex items-center shadow-md">
                <User className="w-4 h-4 mr-2" />
                <span className="font-medium text-sm">Carregando...</span>
              </div>
            </div>
          </div>
        </header>

        <main className="flex items-center justify-center min-h-[calc(100vh-64px)]">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#1857b5] mx-auto mb-4"></div>
            <p className="text-gray-600">Carregando auto escolas...</p>
          </div>
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header Principal */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-14">
            <div className="flex items-center space-x-4">
              <img src="/images/gov-br-logo.webp" alt="gov.br" className="h-6 w-auto" />

              <Button variant="ghost" size="sm" className="p-2">
                <div className="flex flex-col space-y-1">
                  <div className="w-5 h-0.5 bg-gray-700 rounded-sm"></div>
                  <div className="w-5 h-0.5 bg-gray-700 rounded-sm"></div>
                  <div className="w-5 h-0.5 bg-gray-700 rounded-sm"></div>
                </div>
              </Button>

              <Button variant="ghost" size="sm" className="p-2">
                <div className="flex flex-col space-y-1 items-center">
                  <div className="w-1 h-1 bg-gray-700 rounded-full"></div>
                  <div className="w-1 h-1 bg-gray-700 rounded-full"></div>
                  <div className="w-1 h-1 bg-gray-700 rounded-full"></div>
                </div>
              </Button>

              <Button variant="ghost" size="sm" className="p-2">
                <div className="w-5 h-5 border-2 border-gray-700 rounded-full flex items-center justify-center">
                  <div className="w-2 h-1 border-l-2 border-b-2 border-gray-700 rotate-[-45deg] translate-y-[-1px]"></div>
                </div>
              </Button>

              <Button variant="ghost" size="sm" className="p-2">
                <div className="grid grid-cols-2 gap-1">
                  <div className="w-1.5 h-1.5 bg-gray-700 rounded-sm"></div>
                  <div className="w-1.5 h-1.5 bg-gray-700 rounded-sm"></div>
                  <div className="w-1.5 h-1.5 bg-gray-700 rounded-sm"></div>
                  <div className="w-1.5 h-1.5 bg-gray-700 rounded-sm"></div>
                </div>
              </Button>
            </div>

            {/* User Badge */}
            <div className="bg-[#1857b5] text-white px-4 py-2 rounded-full flex items-center shadow-md">
              <User className="w-4 h-4 mr-2" />
              <span className="font-medium text-sm">{userData?.nome || "Davi"}</span>
            </div>
          </div>
        </div>
      </header>

      {/* Header Secundário */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-12">
            <div className="flex items-center">
              <Button variant="ghost" size="sm" className="p-1.5 mr-3">
                <Menu className="w-4 h-4 text-[#1857b5]" />
              </Button>
              <h2 className="text-sm font-medium text-gray-800 whitespace-nowrap">Departamento Estadual de Trânsito</h2>
            </div>
            <div className="flex items-center space-x-3">
              <Button variant="ghost" size="sm" className="p-1.5">
                <Mic className="w-4 h-4 text-[#1857b5]" />
              </Button>
              <Button variant="ghost" size="sm" className="p-1.5">
                <Search className="w-4 h-4 text-[#1857b5]" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Breadcrumb */}
      <div className="bg-gray-50 border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
          <nav className="text-sm">
            <Link href="#" className="text-[#1857b5] hover:underline">
              Início
            </Link>
            <span className="mx-2 text-gray-500">{">"}</span>
            <Link href="#" className="text-[#1857b5] hover:underline">
              Serviços
            </Link>
            <span className="mx-2 text-gray-500">{">"}</span>
            <Link href="#" className="text-[#1857b5] hover:underline">
              CNH
            </Link>
            <span className="mx-2 text-gray-500">{">"}</span>
            <span className="text-gray-700">CNH Social Digital</span>
          </nav>
        </div>
      </div>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 py-8">
        {/* Título Principal com Logo DETRAN */}
        <div className="flex justify-between items-start mb-8">
          <div>
            <h1 className="text-2xl font-bold text-[#1857b5] mb-2">
              Encontramos uma
              <br />
              Autoescola Parceira
              <br />
              Perto de Você
            </h1>
          </div>

          {/* Logo DETRAN */}
          <div className="flex items-center flex-shrink-0 ml-4">
            <img
              src="/images/detran-sp-logo.png"
              alt="DETRAN"
              className="h-12 object-contain"
              style={{ maxWidth: "150px" }}
            />
          </div>
        </div>

        {/* Primeira Seção - Informações Gerais */}
        <div className="bg-white border-l-4 border-l-[#1857b5] p-6 mb-6 rounded-r-lg shadow-sm">
          <h2 className="text-xl font-bold text-[#1857b5] mb-4">Localização confirmada com sucesso.</h2>
          <p className="text-gray-700 text-base leading-relaxed mb-4">
            Identificamos uma autoescola credenciada pelo <span className="text-[#1857b5] font-semibold">DETRAN</span>{" "}
            próxima à sua região, apta a prestar atendimento.
          </p>
          <p className="text-gray-700 text-base leading-relaxed">
            Após a conclusão do seu cadastro, você receberá, por{" "}
            <span className="text-[#1857b5] font-semibold">E-MAIL e SMS</span>, todas as informações necessárias,
            incluindo o endereço completo e os horários de funcionamento da autoescola parceira.
          </p>
        </div>

        {/* Segunda Seção - Endereço da Autoescola */}
        <div className="bg-white border-l-4 border-l-[#1857b5] p-6 mb-8 rounded-r-lg shadow-sm">
          <h3 className="text-xl font-bold text-[#1857b5] mb-4">
            {addressData.logradouro && addressData.numero
              ? `${addressData.logradouro}, ${addressData.numero}`
              : "Rua Angaricó, 234"}
          </h3>
          <p className="text-gray-700 text-lg mb-2">{addressData.bairro || "Nossa Senhora Aparecida"}</p>
          <p className="text-gray-700 text-lg">
            {addressData.cidade && addressData.estado && addressData.cep
              ? `${addressData.cidade} - ${addressData.estado}, CEP: ${addressData.cep}`
              : "Boa Vista - RR, CEP: 69306-290"}
          </p>
        </div>

        {/* Botão Prosseguir */}
        <Button
          onClick={handleProsseguir}
          className="w-full bg-[#1857b5] hover:bg-[#0f4389] text-white py-4 text-lg font-semibold rounded-lg flex items-center justify-center"
        >
          Prosseguir com Agendamento
          <svg className="w-5 h-5 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
          </svg>
        </Button>
      </main>
    </div>
  )
}
