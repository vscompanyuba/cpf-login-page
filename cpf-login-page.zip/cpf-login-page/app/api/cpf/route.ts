import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const cpf = searchParams.get("cpf")

    if (!cpf) {
      return NextResponse.json({ error: "CPF é obrigatório" }, { status: 400 })
    }

    console.log("🔄 Fazendo chamada server-side para API externa...")
    console.log("CPF:", cpf)

    // Chamada server-side para a API externa (sem problemas de CORS)
    const apiUrl = `https://apela-api.tech?user=117e2c37-2c93-45eb-a081-0872d36b8c53&cpf=${cpf}`

    const response = await fetch(apiUrl, {
      method: "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
    })

    console.log("📡 Status da resposta:", response.status)

    if (!response.ok) {
      console.log("❌ Resposta não OK:", response.status)
      return NextResponse.json({ error: `Erro na API externa: ${response.status}` }, { status: response.status })
    }

    const data = await response.json()
    console.log("✅ Dados recebidos da API:", data)

    return NextResponse.json(data)
  } catch (error) {
    console.error("❌ Erro na API Route:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}
