"use client"

import { useEffect, useState, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { User, Menu, Mic, Search, Shield, FileText, Building, ChevronDown } from "lucide-react"
import { useSearchParams, useRouter } from "next/navigation"
import Link from "next/link"

interface UserData {
  nome?: string
  cpf?: string
  error?: string
}

export default function CNHSocialPage() {
  const [userData, setUserData] = useState<UserData | null>(null)
  const [loading, setLoading] = useState(true)
  const searchParams = useSearchParams()
  const router = useRouter()

  const fetchUserData = useCallback(async (cpf: string) => {
    try {
      setLoading(true)

      console.log("🔄 Chamando nossa API Route...")

      // Chamar nossa API Route (server-side) em vez da API externa diretamente
      const response = await fetch(`/api/cpf?cpf=${cpf}`, {
        method: "GET",
        headers: {
          Accept: "application/json",
        },
      })

      console.log("📡 Status da nossa API:", response.status)

      if (response.ok) {
        const data = await response.json()

        console.log("✅ Dados recebidos:", data)

        // Tentar diferentes formas de acessar o nome
        let nomeCompleto = null

        if (data?.nome) {
          nomeCompleto = data.nome
          console.log("Nome encontrado em data.nome:", nomeCompleto)
        } else if (data?.data?.nome) {
          nomeCompleto = data.data.nome
          console.log("Nome encontrado em data.data.nome:", nomeCompleto)
        } else if (data?.name) {
          nomeCompleto = data.name
          console.log("Nome encontrado em data.name:", nomeCompleto)
        } else if (data?.data?.name) {
          nomeCompleto = data.data.name
          console.log("Nome encontrado em data.data.name:", nomeCompleto)
        } else if (Array.isArray(data) && data.length > 0) {
          const firstItem = data[0]
          if (firstItem?.nome) {
            nomeCompleto = firstItem.nome
            console.log("Nome encontrado em array[0].nome:", nomeCompleto)
          } else if (firstItem?.name) {
            nomeCompleto = firstItem.name
            console.log("Nome encontrado em array[0].name:", nomeCompleto)
          }
        }

        if (nomeCompleto) {
          // Extrair apenas o primeiro nome
          const primeiroNome = nomeCompleto.split(" ")[0]
          console.log("✅ Primeiro nome extraído:", primeiroNome)

          setUserData({
            nome: primeiroNome,
            cpf: cpf,
          })
        } else {
          console.log("⚠️ Nome não encontrado na resposta")
          throw new Error("Nome não encontrado na resposta da API")
        }
      } else {
        const errorData = await response.json()
        console.log("❌ Erro da API:", errorData)
        throw new Error(errorData.error || "Erro na API")
      }
    } catch (error) {
      console.log("❌ Erro capturado:", error)

      // Fallback: usar nome simulado baseado no CPF
      const nomesPorCPF = {
        "46960142822": "Roberto",
        "12345678900": "João",
        "98765432100": "Maria",
        "11111111111": "Pedro",
        "22222222222": "Ana",
        "33333333333": "Carlos",
        "44444444444": "Lucia",
        "55555555555": "José",
        "66666666666": "Fernanda",
        "77777777777": "Paulo",
        "88888888888": "Beatriz",
      }

      let nomeSimulado = nomesPorCPF[cpf as keyof typeof nomesPorCPF]

      if (!nomeSimulado) {
        const nomes = ["João", "Maria", "Pedro", "Ana", "Carlos", "Lucia", "José", "Fernanda", "Davi", "Beatriz"]
        const indice = Number.parseInt(cpf.slice(-1)) % nomes.length
        nomeSimulado = nomes[indice]
      }

      console.log("📝 Usando nome simulado:", nomeSimulado)

      setUserData({
        nome: nomeSimulado,
        cpf: cpf,
      })
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    const cpfFromUrl = searchParams.get("cpf")

    if (cpfFromUrl && !userData) {
      fetchUserData(cpfFromUrl)
    } else if (!cpfFromUrl) {
      setLoading(false)
    }
  }, [searchParams, fetchUserData, userData])

  return (
    <div className="min-h-screen bg-white">
      {/* Header Principal */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-14">
            <div className="flex items-center space-x-4">
              <img src="/images/gov-br-logo.webp" alt="gov.br" className="h-6 w-auto" />

              {/* Menu hambúrguer - 3 linhas horizontais mais definidas */}
              <Button variant="ghost" size="sm" className="p-2">
                <div className="flex flex-col space-y-1">
                  <div className="w-5 h-0.5 bg-gray-700 rounded-sm"></div>
                  <div className="w-5 h-0.5 bg-gray-700 rounded-sm"></div>
                  <div className="w-5 h-0.5 bg-gray-700 rounded-sm"></div>
                </div>
              </Button>

              {/* Três pontos verticais mais definidos */}
              <Button variant="ghost" size="sm" className="p-2">
                <div className="flex flex-col space-y-1 items-center">
                  <div className="w-1 h-1 bg-gray-700 rounded-full"></div>
                  <div className="w-1 h-1 bg-gray-700 rounded-full"></div>
                  <div className="w-1 h-1 bg-gray-700 rounded-full"></div>
                </div>
              </Button>

              {/* Círculo com check mais definido */}
              <Button variant="ghost" size="sm" className="p-2">
                <div className="w-5 h-5 border-2 border-gray-700 rounded-full flex items-center justify-center">
                  <div className="w-2 h-1 border-l-2 border-b-2 border-gray-700 rotate-[-45deg] translate-y-[-1px]"></div>
                </div>
              </Button>

              {/* Grid 2x2 mais definido */}
              <Button variant="ghost" size="sm" className="p-2">
                <div className="grid grid-cols-2 gap-1">
                  <div className="w-1.5 h-1.5 bg-gray-700 rounded-sm"></div>
                  <div className="w-1.5 h-1.5 bg-gray-700 rounded-sm"></div>
                  <div className="w-1.5 h-1.5 bg-gray-700 rounded-sm"></div>
                  <div className="w-1.5 h-1.5 bg-gray-700 rounded-sm"></div>
                </div>
              </Button>
            </div>

            {/* User Badge */}
            <div className="bg-[#1857b5] text-white px-4 py-2 rounded-full flex items-center shadow-md">
              <User className="w-4 h-4 mr-2" />
              <span className="font-medium text-sm">{loading ? "Carregando..." : userData?.nome || "Usuário"}</span>
            </div>
          </div>
        </div>
      </header>

      {/* Header Secundário */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-12">
            <div className="flex items-center">
              <Button variant="ghost" size="sm" className="p-1.5 mr-3">
                <Menu className="w-4 h-4 text-[#1857b5]" />
              </Button>
              <h2 className="text-sm font-medium text-gray-800 whitespace-nowrap">Departamento Estadual de Trânsito</h2>
            </div>
            <div className="flex items-center space-x-3">
              <Button variant="ghost" size="sm" className="p-1.5">
                <Mic className="w-4 h-4 text-[#1857b5]" />
              </Button>
              <Button variant="ghost" size="sm" className="p-1.5">
                <Search className="w-4 h-4 text-[#1857b5]" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Breadcrumb */}
      <div className="bg-gray-50 border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
          <nav className="text-sm">
            <Link href="#" className="text-[#1857b5] hover:underline">
              Início
            </Link>
            <span className="mx-2 text-gray-500">{">"}</span>
            <Link href="#" className="text-[#1857b5] hover:underline">
              Serviços
            </Link>
            <span className="mx-2 text-gray-500">{">"}</span>
            <Link href="#" className="text-[#1857b5] hover:underline">
              CNH
            </Link>
            <span className="mx-2 text-gray-500">{">"}</span>
            <span className="text-gray-700">CNH Social Digital</span>
          </nav>
        </div>
      </div>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 py-8">
        {/* Título Principal */}
        <h1 className="text-2xl font-bold text-[#1857b5] mb-6">
          CNH Social Digital 2025: A Oportunidade de Realizar o Seu Sonho
        </h1>

        {/* Conteúdo Principal */}
        <div className="prose max-w-none mb-6">
          <p className="text-base text-gray-700 mb-4">
            O Governo Federal lançou o programa{" "}
            <span className="font-bold text-[#1857b5]">CNH Social Digital 2025</span>, oferecendo a chance de obter sua{" "}
            <span className="font-bold">Carteira Nacional de Habilitação totalmente gratuita</span>, sem custos com
            autoescola e exames. Agora, é possível conquistar a sua habilitação{" "}
            <span className="font-bold">sem que a falta de recursos seja um obstáculo</span>.
          </p>
        </div>

        {/* Logo Brasil */}
        <div className="flex justify-center mb-8">
          <img
            src="/images/governo-federal-logo.png"
            alt="Governo Federal - Brasil - União e Reconstrução"
            className="max-w-md w-full"
          />
        </div>

        {/* Texto Continuação */}
        <div className="prose max-w-none mb-6">
          <p className="text-base text-gray-700 mb-4">
            Milhares de brasileiros enfrentam <span className="font-bold">dificuldades financeiras</span> para dar esse
            importante passo na vida. O CNH Social Digital foi criado para permitir o{" "}
            <span className="font-bold">
              acesso gratuito à 1ª habilitação (
              <Link href="#" className="text-[#1857b5] underline">
                categorias A ou B
              </Link>
              )
            </span>
            , mediante o pagamento de uma taxa de cadastro digital para garantir que apenas cidadãos interessados no
            programa tenham acesso. A iniciativa visa{" "}
            <span className="font-bold">
              ampliar o acesso à mobilidade urbana e promover a inclusão no mercado de trabalho
            </span>
            .
          </p>

          <p className="text-base text-gray-700 mb-4">
            Essa é <span className="font-bold">sua chance</span> de realizar o sonho de dirigir e abrir novas
            oportunidades para a sua vida profissional e pessoal.{" "}
            <span className="font-bold">Aproveite essa chance única</span> e transforme seu futuro agora mesmo!
          </p>
        </div>

        {/* Card Acesso Exclusivo */}
        <Card className="mb-6 border-l-4 border-l-[#1857b5]">
          <CardContent className="p-6">
            <h3 className="text-xl font-bold text-[#1857b5] mb-4">Acesso exclusivo e seguro!</h3>
            <p className="text-gray-700 mb-4">
              Apenas usuários que completarem o processo de verificação podem adquirir o benefício{" "}
              <span className="font-bold">CNH SOCIAL DIGITAL 2025</span> pelo programa oficial.
            </p>
            <div className="flex items-center">
              <Shield className="w-8 h-8 text-[#1857b5] mr-2" />
              <span className="text-gray-700">Compra 100% segura</span>
            </div>
          </CardContent>
        </Card>

        {/* Card Passos */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <h3 className="text-xl font-bold text-gray-800 mb-6">
              Para verificar se você pode obter a CNH Social Digital, siga os passos abaixo:
            </h3>

            <div className="space-y-4 mb-6">
              <div className="flex items-start">
                <div className="bg-[#1857b5] text-white rounded-full w-8 h-8 flex items-center justify-center font-bold mr-4 mt-1 flex-shrink-0">
                  1
                </div>
                <p className="text-gray-700 text-base">Clique no botão abaixo para iniciar sua verificação.</p>
              </div>

              <div className="flex items-start">
                <div className="bg-[#1857b5] text-white rounded-full w-8 h-8 flex items-center justify-center font-bold mr-4 mt-1 flex-shrink-0">
                  2
                </div>
                <p className="text-gray-700 text-base">Preencha os dados para análise de elegibilidade.</p>
              </div>

              <div className="flex items-start">
                <div className="bg-[#1857b5] text-white rounded-full w-8 h-8 flex items-center justify-center font-bold mr-4 mt-1 flex-shrink-0">
                  3
                </div>
                <p className="text-gray-700 text-base">
                  Receba sua análise personalizada e verifique se você está apto a receber o benefício.
                </p>
              </div>
            </div>

            <div className="text-center">
              <Button
                onClick={() => {
                  const cpfFromUrl = searchParams.get("cpf")
                  router.push(`/verificacao?cpf=${cpfFromUrl}`)
                }}
                className="bg-[#1857b5] hover:bg-[#0f4389] text-white px-12 py-5 text-base font-semibold rounded-xl"
              >
                Verificar Elegibilidade
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Seção Descubra */}
        <h2 className="text-2xl font-bold text-[#1857b5] mb-6">
          Descubra se Você Pode Participar do CNH Social Digital 2025
        </h2>

        <div className="space-y-4 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-start">
                <FileText className="w-8 h-8 text-[#1857b5] mr-4 mt-1 flex-shrink-0" />
                <div>
                  <h3 className="text-lg font-bold text-[#1857b5] mb-2">Ter CPF ativo</h3>
                  <p className="text-gray-700">
                    O programa é destinado a cidadãos com CPF regularizado, que podem estar em qualquer parte do Brasil.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-start">
                <FileText className="w-8 h-8 text-[#1857b5] mr-4 mt-1 flex-shrink-0" />
                <div>
                  <h3 className="text-lg font-bold text-[#1857b5] mb-2">Não possuir CNH</h3>
                  <p className="text-gray-700">
                    O benefício é exclusivo para quem nunca teve uma Carteira Nacional de Habilitação ou, caso tenha,
                    não pode estar com ela suspensa ou cassada.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-start">
                <Building className="w-8 h-8 text-[#1857b5] mr-4 mt-1 flex-shrink-0" />
                <div>
                  <h3 className="text-lg font-bold text-[#1857b5] mb-2">Atender a outros critérios locais</h3>
                  <p className="text-gray-700">Cada estado pode definir requisitos adicionais para a inscrição.</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Compartilhe */}
        <div className="text-center mb-8">
          <p className="text-gray-600 mb-4">Compartilhe:</p>
          <div className="flex justify-center space-x-4">
            <Button variant="ghost" size="sm" className="text-blue-600">
              f
            </Button>
            <Button variant="ghost" size="sm" className="text-blue-700">
              in
            </Button>
            <Button variant="ghost" size="sm" className="text-green-600">
              WhatsApp
            </Button>
            <Button variant="ghost" size="sm" className="text-gray-600">
              📋
            </Button>
          </div>
        </div>

        {/* Seção Protocolo */}
        <div className="bg-gradient-to-r from-blue-600 to-blue-800 rounded-lg p-8 text-center text-white mb-8">
          <Button className="bg-yellow-400 hover:bg-yellow-500 text-blue-900 px-8 py-3 rounded-full font-bold text-lg mb-4">
            Clique aqui
          </Button>
          <h3 className="text-xl font-bold mb-4">Para protocolar documentos</h3>
          <p className="mb-4">
            Acesse o <span className="text-yellow-400 font-bold">gov.br/protocolo</span> para enviar documentos, pedidos
            e requerimentos de forma eletrônica
          </p>
          <div className="mt-6">
            <div className="text-2xl font-bold">PROTOCOLO GOV.BR</div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-[#082041] text-white">
        <div className="max-w-7xl mx-auto px-4 py-12">
          <div className="text-center mb-8">
            <img src="/images/logo-white.png" alt="gov.br" className="h-16 mx-auto" />
          </div>

          <div className="space-y-6">
            <div className="border-t border-[#1a365d] pt-6">
              <Button
                variant="ghost"
                className="w-full text-left text-white hover:text-gray-300 flex justify-between items-center"
              >
                <span className="text-lg font-semibold">SERVIÇOS</span>
                <ChevronDown className="w-5 h-5" />
              </Button>
            </div>

            <div className="border-t border-[#1a365d] pt-6">
              <Button
                variant="ghost"
                className="w-full text-left text-white hover:text-gray-300 flex justify-between items-center"
              >
                <span className="text-lg font-semibold">TEMAS EM DESTAQUE</span>
                <ChevronDown className="w-5 h-5" />
              </Button>
            </div>

            <div className="border-t border-[#1a365d] pt-6">
              <Button
                variant="ghost"
                className="w-full text-left text-white hover:text-gray-300 flex justify-between items-center"
              >
                <span className="text-lg font-semibold">NOTÍCIAS</span>
                <ChevronDown className="w-5 h-5" />
              </Button>
            </div>

            <div className="border-t border-[#1a365d] pt-6">
              <Button
                variant="ghost"
                className="w-full text-left text-white hover:text-gray-300 flex justify-between items-center"
              >
                <span className="text-lg font-semibold">POR DENTRO DO GOV.BR</span>
                <ChevronDown className="w-5 h-5" />
              </Button>
            </div>

            <div className="border-t border-[#1a365d] pt-6">
              <Button
                variant="ghost"
                className="w-full text-left text-white hover:text-gray-300 flex justify-between items-center"
              >
                <span className="text-lg font-semibold">CANAIS DO EXECUTIVO FEDERAL</span>
              </Button>
            </div>

            <div className="border-t border-[#1a365d] pt-6">
              <Button
                variant="ghost"
                className="w-full text-left text-white hover:text-gray-300 flex justify-between items-center"
              >
                <span className="text-lg font-semibold">DADOS DO GOVERNO FEDERAL</span>
                <ChevronDown className="w-5 h-5" />
              </Button>
            </div>
          </div>

          <div className="mt-12 pt-8 border-t border-[#1a365d]">
            <h4 className="text-lg font-semibold mb-4">REDES SOCIAIS</h4>
            <div className="flex space-x-4">
              <Button variant="ghost" size="sm" className="text-white hover:text-gray-300">
                📷
              </Button>
              <Button variant="ghost" size="sm" className="text-white hover:text-gray-300">
                f
              </Button>
              <Button variant="ghost" size="sm" className="text-white hover:text-gray-300">
                ▶️
              </Button>
              <Button variant="ghost" size="sm" className="text-white hover:text-gray-300">
                in
              </Button>
              <Button variant="ghost" size="sm" className="text-white hover:text-gray-300">
                💬
              </Button>
              <Button variant="ghost" size="sm" className="text-white hover:text-gray-300">
                🎵
              </Button>
              <Button variant="ghost" size="sm" className="text-white hover:text-gray-300">
                👥
              </Button>
            </div>
          </div>

          <div className="mt-8 flex items-center">
            <div className="bg-white rounded-full p-2 mr-3">
              <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center">
                <span className="text-white text-xs font-bold">i</span>
              </div>
            </div>
            <div>
              <div className="font-semibf">Acesso à</div>
              <div className="font-semibold">Informação</div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
