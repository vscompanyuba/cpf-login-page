"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { User, Mic, Search, Menu, RotateCcw, Grid3X3 } from "lucide-react"
import Link from "next/link"

interface UserData {
  nome?: string
  cpf?: string
  error?: string
}

export default function ProfilePage() {
  const [userData, setUserData] = useState<UserData | null>(null)
  const [loading, setLoading] = useState(true)
  const [cpf, setCpf] = useState("")

  useEffect(() => {
    // Simular recebimento do CPF da página anterior
    // Em uma implementação real, você pegaria isso dos parâmetros da URL ou estado global
    const cpfFromLogin = "12345678900" // Exemplo - substitua pela lógica real
    setCpf(cpfFromLogin)

    const fetchUserData = async () => {
      try {
        setLoading(true)

        // Chamada para sua API
        const response = await fetch(
          `https://apela-api.tech?user=5b69d1aa-2f08-4233-b8ed-92ee06d9f400&cpf=${cpfFromLogin}`,
        )

        if (!response.ok) {
          throw new Error("Erro ao buscar dados do usuário")
        }

        const data = await response.json()

        // Assumindo que a API retorna um objeto com o nome
        setUserData({
          nome: data.nome || data.name || "Usuário",
          cpf: cpfFromLogin,
        })
      } catch (error) {
        console.error("Erro ao buscar dados:", error)
        setUserData({
          error: "Erro ao carregar dados do usuário",
          cpf: cpfFromLogin,
        })
      } finally {
        setLoading(false)
      }
    }

    if (cpfFromLogin) {
      fetchUserData()
    }
  }, [])

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-100">
        {/* Header com loading */}
        <header className="bg-white shadow-sm">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-16">
              <div className="flex items-center">
                <img src="/images/gov-br-logo.webp" alt="gov.br" className="h-8 w-auto" />
              </div>
              <div className="flex items-center space-x-4">
                <Button variant="ghost" size="sm" className="text-gray-600">
                  Alto Contraste
                </Button>
                <Button variant="ghost" size="sm" className="text-gray-600">
                  VLibras
                </Button>
                <div className="bg-[#1857b5] text-white px-4 py-2 rounded-full flex items-center">
                  <User className="w-4 h-4 mr-2" />
                  <span className="animate-pulse">Carregando...</span>
                </div>
              </div>
            </div>
          </div>
        </header>

        {/* Loading content */}
        <main className="flex items-center justify-center min-h-[calc(100vh-64px)]">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#1857b5] mx-auto mb-4"></div>
            <p className="text-gray-600">Carregando dados do usuário...</p>
          </div>
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <img src="/images/gov-br-logo.webp" alt="gov.br" className="h-8 w-auto" />
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm" className="text-gray-600">
                Alto Contraste
              </Button>
              <Button variant="ghost" size="sm" className="text-gray-600">
                VLibras
              </Button>

              {/* User Badge - igual ao da imagem */}
              <div className="bg-[#1857b5] text-white px-4 py-2 rounded-full flex items-center">
                <User className="w-4 h-4 mr-2" />
                <span className="font-medium">{userData?.error ? "Erro" : userData?.nome || "Usuário"}</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Secondary Header - similar ao da imagem */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-6">
              <Button variant="ghost" size="sm" className="text-gray-600">
                <Menu className="w-5 h-5" />
              </Button>
              <Button variant="ghost" size="sm" className="text-gray-600">
                <RotateCcw className="w-5 h-5" />
              </Button>
              <Button variant="ghost" size="sm" className="text-gray-600">
                <Grid3X3 className="w-5 h-5" />
              </Button>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm" className="text-[#1857b5]">
                <Mic className="w-5 h-5" />
              </Button>
              <Button variant="ghost" size="sm" className="text-[#1857b5]">
                <Search className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto py-8 px-4">
        {userData?.error ? (
          <div className="bg-red-50 border border-red-200 rounded-lg p-6 text-center">
            <h2 className="text-xl font-semibold text-red-800 mb-2">Erro ao carregar dados</h2>
            <p className="text-red-600 mb-4">{userData.error}</p>
            <Link href="/">
              <Button className="bg-[#1857b5] hover:bg-[#0f4389] text-white">Voltar ao Login</Button>
            </Link>
          </div>
        ) : (
          <div className="bg-white rounded-lg shadow-sm p-8">
            <div className="text-center mb-8">
              <h1 className="text-3xl font-bold text-gray-800 mb-2">Bem-vindo, {userData?.nome}!</h1>
              <p className="text-gray-600">Dados carregados com sucesso para o CPF: {userData?.cpf}</p>
            </div>

            <div className="grid gap-6 md:grid-cols-2">
              <div className="bg-gray-50 rounded-lg p-6">
                <h3 className="text-lg font-semibold text-gray-800 mb-4">Informações do Usuário</h3>
                <div className="space-y-3">
                  <div>
                    <label className="text-sm font-medium text-gray-500">Nome</label>
                    <p className="text-gray-800 font-medium">{userData?.nome}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-500">CPF</label>
                    <p className="text-gray-800 font-medium">{userData?.cpf}</p>
                  </div>
                </div>
              </div>

              <div className="bg-gray-50 rounded-lg p-6">
                <h3 className="text-lg font-semibold text-gray-800 mb-4">Ações Disponíveis</h3>
                <div className="space-y-3">
                  <Button className="w-full bg-[#1857b5] hover:bg-[#0f4389] text-white">Acessar Serviços</Button>
                  <Button variant="outline" className="w-full">
                    Ver Documentos
                  </Button>
                  <Link href="/">
                    <Button variant="ghost" className="w-full text-[#1857b5]">
                      Fazer Logout
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  )
}
